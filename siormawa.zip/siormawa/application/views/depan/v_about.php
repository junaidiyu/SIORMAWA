<!--//END HEADER -->
<!--//END ABOUT IMAGE -->
<!--============================= WELCOME TITLE =============================-->
<?php
        if($tema->num_rows()>=1){
            foreach($tema->result_array() as $i){
                $header=$i['tema_header'];
                $popup=$i['tema_popup'];
                $body=$i['tema_body'];
                $footer=$i['tema_footer'];
            }
        }
        else{
            $header="#aaaaaa";
            $popup="#cccccc";
            $body="#dddddd";
            $footer="#555555";
        }
?>
<section class="welcome_about" style="background-color: <?php echo $body; ?>;">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h2>History</h2>
                <h3>A. Background</h3>
                <p style="text-align: justify;text-indent: 0.5in">
                    Education is an indicator of the progress of the nation. National education goals according to Law No. 20 of 2003 article 4 states that national education aims to develop the potential of students to be human beings who are faithful and devoted to the Almighty God, noble, healthy, knowledgeable, creative, independent, aesthetic and democratic and have a sense of community and nationality. Seeing the increasingly competitive era, English proficiency which is an international language is the main requirement that must be fulfilled in order to get an important position in society, especially in obtaining jobs, especially in the era of globalization.
                </p>
                <p style="text-align: justify;text-indent: 0.5in">
                    The English Study Club is one of the organizations at Sambas State Polytechnic. This organization is specifically to develop the ability of students who want to know more about English. This organization is actually not only focused on the internal campus but also external to the campus, for example doing community service through one of its work programs.
                    In addition, the organization of English Study Club also holds English race events for members and students, as well as students especially in Sambas Regency. And also this ESC organization often participates in the English competition which is held at the district and national level.
                 </p>

                <h3>B. Purpose and Objectives</h3>
                <p>
                <ol>
                    <li style="text-align: justify;">
                        Collecting students at Sambas State Polytechnic who are interested in developing their talents in English.
                    </li>
                    <li style="text-align: justify;">
                        Maintaining hospitality and family feeling among fellow students who are interested in English at Sambas State Polytechnic.
                    </li>
                </ol>
                </p>

                </div>
                <div class="col-md-5">
                    <img src="<?php echo base_url().'theme/images/ESC.png'?>" class="img-fluid" alt="#">
                </div>
            </div>
        </div>
    </section>
    <!--//END WELCOME TITLE -->
    <!--============================= TESTIMONIAL =============================-->
    <section class="testimonial" style="background-color: <?php echo $body; ?>;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Testimonial</h2>
                </div>
                <div class="col-md-12">
                    <div class="single-item">
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2018.</p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-2.png'?>" class="img-fluid" alt="#">
                                <p><span>Wahyuni Afsari</span>Anggota Terbaik 2018</p>
                            </div>
                        </div>
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2017. </p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-1.png'?>" class="img-fluid" alt="#">
                                <p><span>Muhammad Syamsudin Bahri</span>Anggota Terbaik 2017</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END TESTIMONIAL -->
    <!--============================= DETAILED CHART =============================-->
    <section style="background-color: <?php echo $header; ?>;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_1.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_pengurus;?></span> Organizer
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_2.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_anggota;?></span> Member
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_3.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_files;?></span> Download
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_4.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_agenda;?></span> Agenda</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END DETAILED CHART -->

        <!--============================= FOOTER =============================-->