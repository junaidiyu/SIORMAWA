<!--//END HEADER -->
    <?php
        if($tema->num_rows()>=1){
            foreach($tema->result_array() as $i){
                $header=$i['tema_header'];
                $popup=$i['tema_popup'];
                $body=$i['tema_body'];
                $footer=$i['tema_footer'];
            }
        }
        else{
            $header="#aaaaaa";
            $popup="#cccccc";
            $body="#dddddd";
            $footer="#555555";
        }
    ?>
    <section class="our-teachers" style="background-color: <?php echo $body; ?>;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php foreach($ormawa->result_array() as $i){
                            $kode=$i['ormawa_kode'];
                    }?>
                    <h2 class="mb-5">Organizer of <?php echo $kode;?></h2>
                </div>
            </div>
            <div class="row">
                <?php foreach ($data->result() as $row) : ?>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <div class="admission_insruction">
                          <?php if(empty($row->pengurus_photo)):?>
                            <img src="<?php echo base_url().'assets/images/blank.png';?>" class="img-fluid" alt="#">
                          <?php else:?>
                            <img src="<?php echo base_url().'assets/images/organizer/'.$row->pengurus_photo;?>" class="img-fluid" alt="#">
                          <?php endif;?>
                            <p class="text-center mt-3"><span><?php echo $row->pengurus_nama;?></span>
                                <br>
                            <?php echo $row->jabatan_nama; ?></p>
                                
                        </div>
                    </div>
                <?php endforeach;?>
              </div>
            <!-- End row -->
            <nav><?php echo $page;?></nav>
        </div>
    </section>

    <!--//End Style 2 -->
    <!--============================= FOOTER =============================-->