<!--//END HEADER -->
  <!--============================= Gallery =============================-->
  <?php
        if($tema->num_rows()>=1){
            foreach($tema->result_array() as $i){
                $header=$i['tema_header'];
                $popup=$i['tema_popup'];
                $body=$i['tema_body'];
                $footer=$i['tema_footer'];
            }
        }
        else{
            $header="#aaaaaa";
            $popup="#cccccc";
            $body="#dddddd";
            $footer="#555555";
        }
  ?>
  <div class="gallery-wrap" style="background-color: <?php echo $body; ?>;">
    <div class="container">
      <!-- Style 2 -->
      <div class="row">
        <div class="col-md-12">
          <h3 class="gallery-style">Gallery Photos</h3>
        </div>
      </div><br>
      <div class="row">
        <div class="col-md-12">
          <div id="gallery">
            <div id="gallery-content">
              <div id="gallery-content-center">
                <?php foreach ($all_galeri->result() as $row) : ?>
                  <a href="<?php echo base_url().'assets/images/gallery/'.$row->galeri_gambar;?>" class="image-link2">
                   <img src="<?php echo base_url().'assets/images/gallery/'.$row->galeri_gambar;?>" class="all img-fluid" alt="File not found" />
                  </a>
                <?php endforeach;?>
             </div>
           </div>
         </div>
       </div>
    </div>
      <!--//End Style 2 -->
  </div>
</div>
<!--//End Gallery -->
<!--============================= FOOTER =============================-->