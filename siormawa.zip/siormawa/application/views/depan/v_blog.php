<!--//END HEADER -->
<!--============================= BLOG =============================-->
<?php
        if($tema->num_rows()>=1){
            foreach($tema->result_array() as $i){
                $header=$i['tema_header'];
                $popup=$i['tema_popup'];
                $body=$i['tema_body'];
                $footer=$i['tema_footer'];
            }
        }
        else{
            $header="#aaaaaa";
            $popup="#cccccc";
            $body="#dddddd";
            $footer="#555555";
        }
?>
<section class="blog-wrap" style="background-color: <?php echo $body; ?>;">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
              <?php echo $this->session->flashdata('msg');?>
              <?php foreach ($data->result() as $row) : ?>
                <div class="blog-single-item">
                    <div class="blog-img_block">
                        <a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>"><img src="<?php echo base_url().'assets/images/article/'.$row->tulisan_gambar;?>" class="img-fluid" alt="blog-img"></a>
                        <div class="blog-date">
                            <span><?php echo $row->tanggal;?></span>
                        </div>
                    </div>
                    <div class="blog-tiltle_block">
                        <h4><a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>"><?php echo $row->tulisan_judul;?></a></h4>
                        <h6> <a href="#"><i class="fa fa-user" aria-hidden="true"></i><span><?php echo $row->tulisan_author;?></span> </a>  |   <a href="#"><i class="fa fa-tags" aria-hidden="true"></i><span><?php echo $row->tulisan_kategori_nama;?></span></a></h6>
                        <?php echo limit_words($row->tulisan_isi,10).'...';?>
                        <div class="blog-icons">
                            <div class="blog-share_block">
                                <a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
              <?php endforeach;?>
                <nav>
                    <?php error_reporting(0); echo $page;?>
                </nav>
            </div>
            <div class="col-md-4">
                <form action="<?php echo site_url('blog/search');?>" method="get">
                    <input type="text" name="keyword" placeholder="Search" class="blog-search" required>
                    <button type="submit" class="btn btn-warning btn-blogsearch">SEARCH</button>
                </form>

                


                <div class="blog-category_block">
                  <h3>Category</h3>

                  <nav class="navbar navbar2 navbar-toggleable-md navbar-light" style="background-color: <?php echo $body; ?>;">
                    <ul class="navbar-nav" style="background-color: #ffffff;">
                      <a class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #000000;">
                            Select
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: <?php echo $popup; ?>;">

                            <?php foreach ($category->result() as $row) : ?>
                            <a class="dropdown-item" href="<?php echo site_url('blog/kategori/'.str_replace(" ","-",$row->kategori_nama));?>"><?php echo $row->kategori_nama;?>
                            </a>
                            <?php endforeach ?>
                        </div>
                      </a>
                    </ul>
                  </nav>
                </div>
                <div class="blog-featured_post">
                    <h3>Populer</h3>
                    <?php foreach ($populer->result() as $row) :?>
                      <div class="blog-featured-img_block">
                          <a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>"><img width="35%" src="<?php echo base_url().'assets/images/article/'.$row->tulisan_gambar;?>" class="img-fluid" alt="blog-featured-img"></a>
                          <h5><a href="<?php echo site_url('artikel/'.$row->tulisan_slug);?>"><?php echo limit_words($row->tulisan_judul,3).'...';?></a></h5>
                          <p><?php echo limit_words($row->tulisan_isi,5).'...';?></p>
                      </div>
                      <hr>
                    <?php endforeach;?>
                </div>

            </div>
        </div>
    </div>
</section>
<!--//END BLOG -->
<!--============================= FOOTER =============================-->