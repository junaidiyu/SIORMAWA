<!--//END HEADER -->
<!--//END ABOUT IMAGE -->
<!--============================= WELCOME TITLE =============================-->
<?php
        if($tema->num_rows()>=1){
            foreach($tema->result_array() as $i){
                $header=$i['tema_header'];
                $popup=$i['tema_popup'];
                $body=$i['tema_body'];
                $footer=$i['tema_footer'];
            }
        }
        else{
            $header="#aaaaaa";
            $popup="#cccccc";
            $body="#dddddd";
            $footer="#555555";
        }
?>
<section class="welcome_about" style="background-color: <?php echo $body; ?>;">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Structure of Organization</h2>

                    <div class="table" style="border: hidden;padding: 0px;border-spacing: 0px;">
                        <div class="row">
                            <div class="col">Leader</div>
                            <div class="col">: <b>Junaidi</b></div>
                        </div>
                        <div class="row">
                            <div class="col">Vice Leader</div>
                            <div class="col">: <b>Nurhalimah</b></div>
                        </div>
                        <div class="row">
                            <div class="col">Secretary</div>
                            <div class="col">: <b>Ulan Dini</b></div>
                        </div>
                        <div class="row">
                            <div class="col">Vice Secretary</div>
                            <div class="col">: <b>Nuritasya</b></div>
                        </div>
                        <div class="row">
                            <div class="col">Treasurer</div>
                            <div class="col">: <b>Meida Elvina</b></div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;</div>
                            <div class="col"></div>
                        </div>
                        <div class="row">
                            <div class="col">Division of Creative and <br>Competition</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Elsya Yulihestini</b><br>
                                &nbsp;&nbsp;1. Amalia Riska<br>
                                &nbsp;&nbsp;2. Nia Safitri<br>
                                &nbsp;&nbsp;3. Erlinda<br>
                                &nbsp;&nbsp;4. Dobin Yandi
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;&nbsp;&nbsp;&nbsp; a. Speech</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Khairunisa</b><br>
                                &nbsp;&nbsp;1. M. Syamsudin Bahri<br>
                                &nbsp;&nbsp;2. Mislya<br>
                                &nbsp;&nbsp;3. Salendri
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;&nbsp;&nbsp;&nbsp; b. Storytelling</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Nadia</b><br>
                                &nbsp;&nbsp;1. Yoga Pranata<br>
                                &nbsp;&nbsp;2. Evi Suriani<br>
                                &nbsp;&nbsp;3. Helen
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;&nbsp;&nbsp;&nbsp; c. Debate</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Wahyuni Afsari</b><br>
                                &nbsp;&nbsp;1. Laila Nurani<br>
                                &nbsp;&nbsp;2. Tan Fitri Nur Hidayah<br>
                                &nbsp;&nbsp;3. Laurena Br. Ginting
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;</div>
                            <div class="col"></div>
                        </div>
                        <div class="row">
                            <div class="col">Division of Partnership and <br>Cooperation</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Selviana Kharisma Yanti</b><br>
                                &nbsp;&nbsp;1. Suhaniza<br>
                                &nbsp;&nbsp;2. M. Syaifullah Khanif<br>
                                &nbsp;&nbsp;3. Zulkarnain
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">&nbsp;</div>
                            <div class="col"></div>
                        </div>
                        <div class="row">
                            <div class="col">Division of Promotion dan <br>Information</div>
                            <div class="col">
                                            : <b>CO</b> >> <b>Sri Raniati</b><br>
                                &nbsp;&nbsp;1. Faisal<br>
                                &nbsp;&nbsp;2. Rosita<br>
                                &nbsp;&nbsp;3. Hartati
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-7">
                    <img src="<?php echo base_url().'theme/images/struktur.png'?>" class="img-fluid" alt="Structure of Organization" style="width: 600px;height: 600px">
                </div>
            </div>
        </div>
    </section>
    <!--//END WELCOME TITLE -->
    <!--============================= TESTIMONIAL =============================-->
    <section class="testimonial" style="background-color: <?php echo $popup; ?>;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Testimonial</h2>
                </div>
                <div class="col-md-12">
                    <div class="single-item">
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2018.</p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-2.png'?>" class="img-fluid" alt="#">
                                <p><span>Wahyuni Afsari</span>Anggota Terbaik 2018</p>
                            </div>
                        </div>
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2017. </p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-1.png'?>" class="img-fluid" alt="#">
                                <p><span>Muhammad Syamsudin Bahri</span>Anggota Terbaik 2017</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END TESTIMONIAL -->
    <!--============================= DETAILED CHART =============================-->
    <section style="background-color: <?php echo $header; ?>;">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_1.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_pengurus;?></span> Organizer
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_2.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_anggota;?></span> Member
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_3.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_files;?></span> Download
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_4.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_agenda;?></span> Agenda</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END DETAILED CHART -->

        <!--============================= FOOTER =============================-->