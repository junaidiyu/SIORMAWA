<footer class="main-footer" style="background-color: #dddd55">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo date('Y');?> ESC <a href="http://poltesa.ac.id" target="blank">POLTESA</a></strong> All rights reserved
</footer>