<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $judul ?></title>
    <link rel="shorcut icon" href="<?php echo base_url().'theme/images/ESC.png'?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/bootstrap.min.css'?>">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/font-awesome.min.css'?>">
    <!-- Simple Line Font -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/simple-line-icons.css'?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/magnific-popup.css'?>">
    <!-- Image Hover CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'theme/css/normalize.css'?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'theme/css/set2.css'?>" />
    <!-- Calendar Css -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/fullcalendar.min.css'?>" />
    <!-- Slider / Carousel -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/slick.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/slick-theme.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/owl.carousel.min.css'?>">
    <!-- Masonry Gallery -->
    <link href="<?php echo base_url().'theme/css/animated-masonry-gallery.css'?>" rel="stylesheet" type="text/css"/>
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/iCheck/square/blue.css'?>">
    <!-- Main CSS -->
    <link href="<?php echo base_url().'theme/css/style.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'theme/css/dataTables.bootstrap4.min.css'?>" rel="stylesheet">
    <?php
        function limit_words($string, $word_limit){
            $words = explode(" ",$string);
            return implode(" ",array_splice($words,0,$word_limit));
        }
    ?>
</head>

<body>
    <!--============================= HEADER =============================-->
    <div class="header-topbar" style="background-color: #555555;">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-8 col-md-9">
                    <div class="header-top_address">
                        <div class="header-top_list">
                            <span class="icon-phone"></span>+62 85348908640
                        </div>
                        <div class="header-top_list">
                            <span class="icon-envelope-open"></span>escpoltesa@gmail.com
                        </div>
                     <!--   <div class="header-top_list">
                            <span class="icon-location-pin"></span>Jl. Raya Sejangkung, Tumuk Manggis, Sambas, Kalimantan Barat
                        </div>
                -->    </div>
                    <div class="header-top_login2">
                        <a href="<?php echo site_url('contact');?>">Google Maps</a>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3">
                    <div class="header-top_login mr-sm-3">
                        <span class="icon-location-pin"></span> <a href="<?php echo site_url('contact');?>">Google Maps</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div data-toggle="affix" style="background-color: #dddd55;">
        <div class="container nav-menu2">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar2 navbar-toggleable-md navbar-light" style="background-color: #dddd55;">
                        <button class="navbar-toggler navbar-toggler2 navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
                            <span class="icon-menu"></span>
                        </button>
                        <a href="<?php echo site_url('');?>" class="navbar-brand nav-brand2"><img class="img img-responsive" width="80px;" src="<?php echo base_url().'theme/images/ESC.png'?>"></a>
                        <h2><b>ESC</b></h2>
                        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('');?>">Home</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      About
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #ffffaa;">
                                        <a class="dropdown-item" href="<?php echo site_url('visi_misi');?>">Vision and Mission</a>
                                        <a class="dropdown-item" href="<?php echo site_url('struktur');?>">Structure of Organization</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="<?php echo site_url('about');?>">History of ESC</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Family
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #ffffaa;">
                                        <a class="dropdown-item" href="<?php echo site_url('organizer');?>">Organizer</a>
                                        <a class="dropdown-item" href="<?php echo site_url('member');?>">Member</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#">Alumni</a>
                                    </div>
                                </li>
                            <!--    <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('organizer');?>">Organizer</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('member');?>">Member</a>
                                </li>
                            -->    <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('blog');?>">Blog</a>
                                </li>
                            <!--    <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('pengumuman');?>">Announcement</a>
                            -->    </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('agenda');?>">Agenda</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('download');?>">Download</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo site_url('galeri');?>">Gallery</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="<?php echo site_url('contact');?>">Contact</a>
                                </li>
                                <li class="nav-item">
                                  <a class="nav-link" href="<?php echo site_url('#');?>">Register</a>
                                </li>
                                
                                 <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Login
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #ffffaa;">
                                        
                                        <div class="login-box">
                                          <div>
                                           <p><?php echo $this->session->flashdata('msg');?></p>
                                          </div>
                                          <!-- /.login-logo -->

                                          <div class="login-box-body" style="background-color: #ffffcc">
                                           <!-- <p class="login-box-msg"> <img width="200px;" src="<?php echo base_url().'theme/images/ESC.png'?>"></p><hr/> -->

                                            <form action="<?php echo site_url().'admin/login/auth'?>" method="post">
                                              <div class="form-group has-feedback">
                                                <input type="text" name="username" class="form-control" placeholder="Username" required>
                                                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                                              </div>
                                              <div class="form-group has-feedback">
                                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                                                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                                              </div>
                                              <div class="row">
                                                <div class="col-md-12" align="right">
                                                  <div class="checkbox icheck">
                                                    <label>
                                                      <input type="checkbox"> Remember Me
                                                    </label>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="row">
                                                <!-- /.col -->
                                                <div class="col-md-6">
                                                  <button type="reset" class="btn btn-danger btn-block btn-flat">Reset</button>
                                                </div>
                                                <!-- /.col -->
                                                <div class="col-md-6">
                                                  <button type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
                                                </div>
                                                <!-- /.col -->
                                              </div>
                                            </form>
                                          </div> 
                                          <!-- /.login-box-body -->
                                        </div>           
                                    </div>
                                </li>
                             </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
      </div>
    <section>
</section>