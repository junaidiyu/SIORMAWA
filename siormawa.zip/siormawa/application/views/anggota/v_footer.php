<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="foot-logo">
                    <a href="<?php echo site_url();?>">
                        <img src="<?php echo base_url().'theme/images/ESC.png'?>" class="img-fluid" width="100px;" alt="footer_logo">
                    </a>
                    <p>© <?php echo date('Y');?> copyright by <br> <a href="http://polesa.ac.id" target="_blank">POLTESA</a> <br>All rights reserved <br></br><em>Designed By Junaidi</em></p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="sitemap">
                        <h3>Main Menu</h3>
                        <ul>
                            <li><a href="<?php echo site_url();?>">Home</a></li>
                            <li><a href="<?php echo site_url('about');?>">About</a></li>
                            <li><a href="<?php echo site_url('artikel');?>">Blog </a></li>
                            <li><a href="<?php echo site_url('galeri');?>">Gallery</a></li>
                            <li><a href="<?php echo site_url('contact');?>">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                  <div class="sitemap">
                      <h3>Organization</h3>
                      <ul>
                          <li><a href="<?php echo site_url('organizer');?>">Organizer</a></li>
                          <li><a href="<?php echo site_url('member');?>">Member </a></li>
                          <li><a href="<?php echo site_url('pengumuman');?>">Announcement</a></li>
                          <li><a href="<?php echo site_url('agenda');?>">Agenda</a></li>
                          <li><a href="<?php echo site_url('download');?>">Download</a></li>
                      </ul>
                  </div>
                </div>
                <div class="col-md-3">
                    <div class="address">
                        <h3>Contact Us</h3>
                        <p><span>Address : </span>Jl. Raya Sejangkung, Tumuk Manggis, Sambas, Kalimantan Barat</p>
                        <p><span class="icon-envelope-open"></span> escpoltesa@gmail.com
                            <br><span class="icon-phone"></span> 085348908640
                            <br><span class="icon-location-pin"></span> <a href="<?php echo site_url('contact');?>">Google Maps</a></p>
                            <ul class="footer-social-icons">
                                <li><a href="#"><i class="fa fa-facebook fa-fb" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin fa-in" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter fa-tw" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--//END FOOTER -->
        <!-- jQuery, Bootstrap JS. -->
        <script src="<?php echo base_url().'theme/js/jquery.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/tether.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/bootstrap.min.js'?>"></script>
        <!-- Plugins -->
        <script src="<?php echo base_url().'theme/js/slick.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/waypoints.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/counterup.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/owl.carousel.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/validate.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/tweetie.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/moment.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/fullcalendar.min.js'?>"></script>
        <!-- Subscribe -->
        <script src="<?php echo base_url().'theme/js/subscribe.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/contact.js'?>"></script>

        <script src="<?php echo base_url().'theme/js/jquery-ui-1.10.4.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/jquery.isotope.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/animated-masonry-gallery.js'?>"></script>
        <!-- Magnific popup JS -->
        <script src="<?php echo base_url().'theme/js/jquery.magnific-popup.js'?>"></script>
        <!-- Script JS -->
        <script src="<?php echo base_url().'theme/js/script.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/jquery.dataTables.min.js'?>"></script>
        <script src="<?php echo base_url().'theme/js/dataTables.bootstrap4.min.js'?>"></script>

        <script>
              $(document).ready(function() {
                $('#display').DataTable();
              });
        </script>

        
    </body>

</html>