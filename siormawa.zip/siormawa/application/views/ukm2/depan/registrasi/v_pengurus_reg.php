        <section class="welcome_about">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <h2>Organizor Open Registration</h2> <br>
                        <h3>A. Prerequirement and Condition</h3>
                            <ol style="text-align: justify;">
                                <li>Must be Student of Sambas State Politechnic.</li>
                                <li>Maximum in 5th semester for D-3 and 7th semester for D-4.</li>
                                <li>Minimum in 3rd semester.</li>
                                <li>Can cooporate together as team.</li>
                                <li>Active.</li>
                            </ol>

                        <h3>B. Site and Place</h3>
                            <ol style="text-align: justify;">
                              <li>For online registration you can see the site and email on the pamflet.</li>
                              <li>For offline registration you can come to campus of Sambas State Politechnic.</li>
                              <li>Leave us message at our site or email and also our social media for more information.</li>
                            </ol>
                    </div>
                    <div class="col-md-5">
                        <img src="<?php echo base_url().'assets/images/user_blank.png'?>" class="img-fluid" alt="#">
                    </div>
                </div>
            </div>
        </section>

        <section class="testimonial">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Testimonial</h2>
                </div>
                <div class="col-md-12">
                    <div class="single-item">
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2018.</p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-2.png'?>" class="img-fluid" alt="#">
                                <p><span>Wahyuni Afsari</span>Anggota Terbaik 2018</p>
                            </div>
                        </div>
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2017. </p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-1.png'?>" class="img-fluid" alt="#">
                                <p><span>Muhammad Syamsudin Bahri</span>Anggota Terbaik 2017</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END TESTIMONIAL -->
    <!--============================= DETAILED CHART =============================-->
   