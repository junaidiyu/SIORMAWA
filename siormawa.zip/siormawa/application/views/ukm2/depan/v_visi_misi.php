<!--//END HEADER -->
<!--//END ABOUT IMAGE -->
<!--============================= WELCOME TITLE =============================-->
<section class="welcome_about">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h2>Vision and Mission</h2>
                <h3>A. Vision</h3>
                <p style="text-align: justify;text-indent: 0.5in">
                    Making ESC an active organization capable of fostering self-confident, active, creative and competitive people by developing the interests and talents of students and society, so as to be able to cooperate and compete at the regional, national and international levels.
                </p>
                <h3>B. Mission</h3>
                    <ol style="text-align: justify;">
                        <li>Make ESC closer to the community and be able to introduce the importance of English.</li>
                        <li>Make ESC as one of the active organizations that many students are interested in.
                        </li>
                        <li>Strengthen ESC family relationships that are able to work together, actively and productively.</li>
                        <li>Make ESC activities more interesting, fun and educative.</li>
                        <li>Establish creative and competitive people who are able to compete at the regional, national and international levels.</li>
                    </ol>

                </div>
                <div class="col-md-5">
                    <img src="<?php echo base_url().'assets/images/organizer/ketum.jpg'?>" class="img-fluid" alt="#">
                </div>
            </div>
        </div>
    </section>
    <!--//END WELCOME TITLE -->
    <!--============================= TESTIMONIAL =============================-->
    <section class="testimonial">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Testimonial</h2>
                </div>
                <div class="col-md-12">
                    <div class="single-item">
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2018.</p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-2.png'?>" class="img-fluid" alt="#">
                                <p><span>Wahyuni Afsari</span>Anggota Terbaik 2018</p>
                            </div>
                        </div>
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">ESC benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan ESC dan menjadi anggota terbaik tahun 2017. </p>
                            <div class="testi-img_block">
                                <img src="<?php echo base_url().'theme/images/student-1.png'?>" class="img-fluid" alt="#">
                                <p><span>Muhammad Syamsudin Bahri</span>Anggota Terbaik 2017</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//END TESTIMONIAL -->
    <!--============================= DETAILED CHART =============================-->
    <div class="detailed_chart">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_1.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_pengurus;?></span> Organizer
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_2.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_anggota;?></span> Member
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_top">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_3.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_files;?></span> Download
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="chart-img">
                        <img src="<?php echo base_url().'theme/images/chart-icon_4.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php echo $tot_agenda;?></span> Agenda</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--//END DETAILED CHART -->

        <!--============================= FOOTER =============================-->