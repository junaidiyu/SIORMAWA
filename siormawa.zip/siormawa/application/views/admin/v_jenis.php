  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Jenis Organisasi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Jenis</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Jenis</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/jenis_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                    $no=0;
                    foreach ($data->result_array() as $i) :
                       $no++;
                       $id=$i['jenis_id'];
                       $kode=$i['jenis_kode'];
                       $nama=$i['jenis_nama'];
                    ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $kode;?></td>
                      <td><?php echo $nama;?></td>
                      <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                      </td>
                    </tr>
                 <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Jenis-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Jenis</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/jenis/simpan_jenis'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputJenis" class="col-sm-4 control-label">Kode</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xkode" class="form-control" id="inputJenis" placeholder="Kode Jenis" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputJenis" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputJenis" placeholder="Nama Jenis" required>
                                        </div>
                                    </div>
                                    
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

  <!--Modal Edit Jenis-->
  <?php foreach ($data->result_array() as $i) :
              $id=$i['jenis_id'];
              $kode=$i['jenis_kode'];
              $nama=$i['jenis_nama'];
            ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Jenis</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/jenis/update_jenis'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                                <div class="form-group">
                                    <label for="inputJenis" class="col-sm-4 control-label">Kode</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="xkode" value="<?php echo $kode;?>" class="form-control" id="inputJenis" placeholder="KODE" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputJenis" class="col-sm-4 control-label">Nama</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputJenis" placeholder="Nama" required>
                                    </div>
                                </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>
  <!--Modal Delete Jenis-->

  <?php foreach ($data->result_array() as $i) :
              $id=$i['jenis_id'];
              $kode=$i['jenis_kode'];
              $nama=$i['jenis_nama'];
            ?>
  <!--Modal Hapus Jenis-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Jenis</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/jenis/hapus_jenis'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                     <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                            <p>Apakah Anda yakin mahu menghapus jenis <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>

