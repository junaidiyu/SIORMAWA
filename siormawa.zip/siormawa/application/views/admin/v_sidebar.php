<?php
    $tema_header="#999999";
    $tema_popup="#cccccc";
    $tema_body="#dddddd";
    $tema_sidebar="#222222";
    $tema_footer="#999999";
?>

  <!--Counter Inbox-->
<?php
    $query=$this->db->query("SELECT * FROM tbl_inbox WHERE inbox_status='1'");
    $query2=$this->db->query("SELECT * FROM tbl_komentar WHERE komentar_status='0'");
    $jum_comment=$query2->num_rows();
    $jum_pesan=$query->num_rows();
?>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar" style="background-color: <?php echo $tema_sidebar;?>">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">

        <li class="header">Menu Utama</li>
        
        <li >
          <a href="<?php echo base_url().'admin/pengguna'?>">
            <i class="fa fa-user"></i> <span>ADMINISTRATOR</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-institution"></i>
            <span> KAMPUS</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li ><a href="<?php echo base_url().'admin/kampus'?>"><i class="fa fa-list"></i>List Kampus</a></li>
            <li ><a href="<?php echo base_url().'admin/jurusan'?>"><i class="fa fa-gear"></i>Jurusan</a></li>
            <li ><a href="<?php echo base_url().'admin/prodi'?>"><i class="fa fa-gear"></i>Program Studi</a></li>
          </ul>
        </li>



        <li class="treeview">
          <a href="#">
            <i class="fa fa-graduation-cap"></i>
            <span> ORGANISASI<br>
            &nbsp&nbsp&nbsp&nbsp&nbsp MAHASISWA</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li >
              <a href="<?php echo base_url().'admin/dashboard'?>">
                <i class="fa fa-home"></i> <span>Dashboard</span>
                <span class="pull-right-container">
                  <small class="label pull-right"></small>
                </span>
              </a>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-info-circle"></i>
                <span>Profil</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li ><a href="<?php echo base_url().'admin/ormawa'?>"><i class="fa fa-list"></i>List Organisasi</a></li>
                <li ><a href="<?php echo base_url().'admin/jenis'?>"><i class="fa fa-gear"></i>Jenis Organisasi</a></li>
                <li ><a href="<?php echo base_url().'admin/divisi'?>"><i class="fa fa-gear"></i>Divisi</a></li>
                <li ><a href="<?php echo base_url().'admin/jabatan'?>"><i class="fa fa-gear"></i>Jabatan</a></li>
                <li ><a href="<?php echo base_url().'admin/sambutan'?>"><i class="fa fa-hand-paper-o"></i>Sambutan</a></li>
                <li ><a href="<?php echo base_url().'admin/visimisi'?>"><i class="fa fa-eye"></i>Visi Misi</a></li>
                <li ><a href="<?php echo base_url().'admin/struktur'?>"><i class="fa fa-sitemap"></i>Struktur</a></li>
                <li ><a href="<?php echo base_url().'admin/fungsi'?>"><i class="fa fa-history"></i>Sejarah dan Fungsi</a></li>
                <li ><a href="<?php echo base_url().'admin/kontak'?>"><i class="fa fa-phone"></i>Kontak</a></li>
                <li ><a href="<?php echo base_url().'admin/tema'?>"><i class="fa fa-file-image-o"></i>Tema Website</a></li>
                <li ><a href="<?php echo base_url().'admin/file'?>"><i class="fa fa-file"></i>File</a></li>
              </ul>
            </li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-users"></i>
                <span>Keanggotaan</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li ><a href="<?php echo base_url().'admin/pengurus'?>"><i class="fa fa-users"></i>List Pengurus</a></li>
                <li ><a href="<?php echo base_url().'admin/anggota'?>"><i class="fa fa-users"></i>List Anggota</a></li>
              
              </ul>
            </li>

            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i>
                <span>Konten</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-newspaper-o"></i>
                    <span>Artikel</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <li ><a href="<?php echo base_url().'admin/tulisan'?>"><i class="fa fa-list"></i> List Artikel</a></li>
                    <li ><a href="<?php echo base_url().'admin/tulisan/add_tulisan'?>"><i class="fa fa-thumb-tack"></i> Post Artikel</a></li>
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i> Kategori Artikel</a></li>
                  </ul>
                </li>
                
                <li >
                  <a href="<?php echo base_url().'admin/agenda'?>">
                    <i class="fa fa-calendar"></i> <span>Agenda</span>
                    <span class="pull-right-container">
                      <small class="label pull-right"></small>
                    </span>
                  </a>
                </li>
                <li >
                  <a href="<?php echo base_url().'admin/pengumuman'?>">
                    <i class="fa fa-volume-up"></i> <span>Pengumuman</span>
                    <span class="pull-right-container">
                      <small class="label pull-right"></small>
                    </span>
                  </a>
                </li>
                <li >
                  <a href="<?php echo base_url().'admin/files'?>">
                    <i class="fa fa-download"></i> <span>Download</span>
                    <span class="pull-right-container">
                      <small class="label pull-right"></small>
                    </span>
                  </a>
                </li>
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-camera"></i>
                    <span>Gallery</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <li ><a href="<?php echo base_url().'admin/album'?>"><i class="fa fa-clone"></i> Album</a></li>
                    <li ><a href="<?php echo base_url().'admin/galeri'?>"><i class="fa fa-picture-o"></i> Photos</a></li>
                  </ul>
                </li>
                <li >
                  <a href="<?php echo base_url().'admin/slider'?>">
                    <i class="fa fa-star-o"></i> <span>Slider</span>
                    <span class="pull-right-container">
                      <small class="label pull-right"></small>
                    </span>
                  </a>
                </li>

              </ul>
            </li>
        
            <li class="treeview">
              <a href="#">
                <i class="fa fa-newspaper-o"></i>
                <span>Layanan</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-wrench"></i>
                    <span>Program Kerja</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i>Proposal</a></li>
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i>Surat</a></li>
                  </ul>
                </li>
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-wrench"></i>
                    <span>Arsip</span>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i>Kegiatan</a></li>
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i>Surat Masuk</a></li>
                    <li ><a href="<?php echo base_url().'admin/kategori'?>"><i class="fa fa-wrench"></i>Surat Keluar</a></li>
                  </ul>
                </li>
              </ul>
            </li>

            <li >
              <a href="<?php echo base_url().'admin/inbox'?>">
                <i class="fa fa-envelope"></i> <span>Inbox</span>
                <span class="pull-right-container">
                  <small class="label pull-right bg-green"><?php echo $jum_pesan;?></small>
                </span>
              </a>
            </li>

            <li >
              <a href="<?php echo base_url().'admin/komentar'?>">
                <i class="fa fa-comments"></i> <span>Komentar</span>
                <span class="pull-right-container">
                  <small class="label pull-right bg-green"><?php echo $jum_comment;?></small>
                </span>
              </a>
            </li>
          </ul>
        </li>




        <li class="treeview">
          <a href="#">
            <i class="fa fa-archive"></i>
            <span>BIRO<br>
            &nbsp&nbsp&nbsp&nbsp&nbsp KEMAHASISWAAN</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li >
              <a href="<?php echo base_url().'admin/dashboard'?>">
                <i class="fa fa-home"></i> <span>Dashboard</span>
                <span class="pull-right-container">
                  <small class="label pull-right"></small>
                </span>
              </a>
            </li>

            <li >
              <a href="<?php echo base_url().'admin/pengguna'?>">
                <i class="fa fa-users"></i> <span>Progja</span>
                <span class="pull-right-container">
                  <small class="label pull-right"></small>
                </span>
              </a>
            </li>

            <li >
              <a href="<?php echo base_url().'admin/pengguna'?>">
                <i class="fa fa-users"></i> <span>Chat</span>
                <span class="pull-right-container">
                  <small class="label pull-right"></small>
                </span>
              </a>
            </li>

             <li >
              <a href="<?php echo base_url().'admin/inbox'?>">
                <i class="fa fa-envelope"></i> <span>Inbox</span>
                <span class="pull-right-container">
                  <small class="label pull-right bg-green"><?php echo $jum_pesan;?></small>
                </span>
              </a>
            </li>

            <li >
              <a href="<?php echo base_url().'admin/komentar'?>">
                <i class="fa fa-comments"></i> <span>Komentar</span>
                <span class="pull-right-container">
                  <small class="label pull-right bg-green"><?php echo $jum_comment;?></small>
                </span>
              </a>
            </li>
          </ul>
        </li>




        <li>
          <a href="<?php echo base_url().'admin/login/logout'?>">
            <i class="fa fa-sign-out"></i> <span>Logout</span>
            <span class="pull-right-container">
              <small class="label pull-right"></small>
            </span>
          </a>
        </li>

      </ul>

    </section>
    <!-- /.sidebar -->
  </aside>