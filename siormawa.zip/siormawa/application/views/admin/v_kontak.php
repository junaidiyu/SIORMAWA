  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Kontak
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Kontak</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Kontak</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/kontak_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Facbook</th>
                    <th>Instagram</th>
                    <th>Youtube</th>
                    <th>Author</th>
                    <th>Tanggal Input</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                    $no=0;
                    foreach ($data->result_array() as $i) :
                       $no++;
                       $id=$i['kontak_id'];
                       $nama=$i['kontak_nama'];
                       $email=$i['kontak_email'];
                       $wa=$i['kontak_wa'];
                       $fb=$i['kontak_fb'];
                       $ig=$i['kontak_ig'];
                       $yt=$i['kontak_yt'];
                       $author=$i['kontak_author'];
                       $tgl_input=$i['kontak_tgl_input'];
                    ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $nama;?></td>
                      <td><?php echo $email;?></td>
                      <td><?php echo $wa;?></td>
                      <td><?php echo $fb;?></td>
                      <td><?php echo $ig;?></td>
                      <td><?php echo $yt;?></td>
                      <td><?php echo $author;?></td>
                      <td><?php echo $tgl_input;?></td>
                      <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                      </td>
                    </tr>
                 <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Kontak-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Kontak</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kontak/simpan_kontak'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputKontak" placeholder="Nama Kontak" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xemail" class="form-control" id="inputKontak" placeholder="email" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Telepon</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xwhatsapp" class="form-control" id="inputKontak" placeholder="telepon" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Facebook</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xfacebook" class="form-control" id="inputKontak" placeholder="facebook" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Instagram</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xinstagram" class="form-control" id="inputKontak" placeholder="instagram" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Youtube</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xyoutube" class="form-control" id="inputKontak" placeholder="youtube" required>
                                        </div>
                                    </div>

                                    
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--Modal Edit Kontak-->
        <?php foreach ($data->result_array() as $i) :
          $id=$i['kontak_id'];
          $nama=$i['kontak_nama'];
          $email=$i['kontak_email'];
          $wa=$i['kontak_wa'];
          $fb=$i['kontak_fb'];
          $ig=$i['kontak_ig'];
          $yt=$i['kontak_yt'];
          $author=$i['kontak_author'];
          $tgl_input=$i['kontak_tgl_input'];
        ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Kontak</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kontak/update_kontak'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputKontak" placeholder="Nama Kontak" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xemail" value="<?php echo $email;?>" class="form-control" id="inputKontak" placeholder="email" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Telepon</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xwhatsapp" value="<?php echo $wa;?>" class="form-control" id="inputKontak" placeholder="telepon" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Facebook</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xfacebook" value="<?php echo $fb;?>" class="form-control" id="inputKontak" placeholder="facebook" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Instagram</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xinstagram" value="<?php echo $ig;?>" class="form-control" id="inputKontak" placeholder="instagram" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKontak" class="col-sm-4 control-label">Youtube</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xyoutube" value="<?php echo $yt;?>" class="form-control" id="inputKontak" placeholder="youtube" required>
                                        </div>
                                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
      <?php endforeach;?>
      <!--Modal Delete Kontak-->

      <?php foreach ($data->result_array() as $i) :
              $id=$i['kontak_id'];
              $nama=$i['kontak_nama'];
              $email=$i['kontak_email'];
              $wa=$i['kontak_wa'];
              $fb=$i['kontak_fb'];
              $ig=$i['kontak_ig'];
              $yt=$i['kontak_yt'];
              $author=$i['kontak_author'];
              $tgl_input=$i['kontak_tgl_input'];
      ?>
      <!--Modal Hapus Kontak-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Kontak</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kontak/hapus_kontak'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                     <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                            <p>Apakah Anda yakin mahu menghapus kontak <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>

