  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Kampus
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Kampus</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Kampus</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/kampus_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Logo</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Website</th>
                    <th>Author</th>
                    <th>Tanggal Input</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
          				<?php
          					$no=0;
          					foreach ($data->result_array() as $i) :
          					   $no++;
          					   $id=$i['kampus_id'];
          					   $kode=$i['kampus_kode'];
          					   $nama=$i['kampus_nama'];
          					   $email=$i['kampus_email'];
                       $alamat=$i['kampus_alamat'];
                       $website=$i['kampus_website'];
                       $logo=$i['kampus_logo'];
                       $author=$i['kampus_author'];
                       $tgl_input=$i['kampus_tgl_input'];
                    ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <?php if(empty($logo)):?>
                      <td></td>
                      <?php else:?>
                      <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/campus/'.$logo;?>"></td>
                      <?php endif;?>
                      <td><?php echo $kode;?></td>
                      <td><?php echo $nama;?></td>
                      <td><?php echo $email;?></td>
                      <td><?php echo $alamat;?></td>
                      <td><?php echo $website;?></td>
                      <td><?php echo $author;?></td>
                      <td><?php echo $tgl_input;?></td>
                      <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-search"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                      </td>
                    </tr>
			   	       <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Kampus-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Kampus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kampus/simpan_kampus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Kode</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xkode" class="form-control" id="inputKampus" placeholder="KODE" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputKampus" placeholder="Nama" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="email" name="xemail" class="form-control" id="inputKampus" placeholder="email" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" class="form-control" id="inputKampus" placeholder="Alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Website</label>
                                        <div class="col-sm-7">
                                            <input type="url" name="xwebsite" class="form-control" id="inputKampus" placeholder="http://" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">logo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

  <!--Modal Edit Kampus-->
  <?php foreach ($data->result_array() as $i) :
              $id=$i['kampus_id'];
              $kode=$i['kampus_kode'];
              $nama=$i['kampus_nama'];
              $email=$i['kampus_email'];
              $alamat=$i['kampus_alamat'];
              $website=$i['kampus_website'];
              $logo=$i['kampus_logo'];
            ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Kampus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kampus/update_kampus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                                <input type="hidden" value="<?php echo $logo;?>" name="gambar">
                                <div class="form-group">
                                    <label for="inputKampus" class="col-sm-4 control-label">Kode</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="xkode" value="<?php echo $kode;?>" class="form-control" id="inputKampus" placeholder="KODE" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputKampus" class="col-sm-4 control-label">Nama</label>
                                    <div class="col-sm-7">
                                        <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputKampus" placeholder="Nama" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="email" name="xemail" value="<?php echo $email;?>" class="form-control" id="inputKampus" placeholder="email" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" value="<?php echo $alamat;?>" class="form-control" id="inputKampus" placeholder="alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputKampus" class="col-sm-4 control-label">Website</label>
                                        <div class="col-sm-7">
                                            <input type="url" name="xwebsite" value="<?php echo $website;?>" class="form-control" id="inputKampus" placeholder="http://" required>
                                        </div>
                                    </div>

                                <div class="form-group">
                                    <label for="inputKampus" class="col-sm-4 control-label">Logo</label>
                                    <div class="col-sm-7">
                                        <input type="file" name="filefoto"/>
                                    </div>
                                </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>
	<!--Modal Delete Kampus-->

	<?php foreach ($data->result_array() as $i) :
              $id=$i['kampus_id'];
              $kode=$i['kampus_kode'];
              $nama=$i['kampus_nama'];
              $email=$i['kampus_email'];
              $alamat=$i['kampus_alamat'];
              $website=$i['kampus_website'];
              $logo=$i['kampus_logo'];
            ?>
	<!--Modal Hapus Kampus-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Kampus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/kampus/hapus_kampus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							       <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                     <input type="hidden" value="<?php echo $logo;?>" name="gambar">
                            <p>Apakah Anda yakin mahu menghapus kampus <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

