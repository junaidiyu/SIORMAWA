
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Anggota
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Anggota</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Anggota</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/anggota_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
          					<th>Photo</th>
          					<th>NIM</th>
          					<th>Nama</th>
          					<th>Jenis Kelamin</th>
                    <th>No Telephone</th>
                    <th>Alamat</th>
                    <th>Program Studi</th>
                    <th>Angkatan</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
          				<?php
          					$no=0;
          					foreach ($data->result_array() as $i) :
          					   $no++;
          					   $id=$i['anggota_id'];
          					   $nim=$i['anggota_nim'];
          					   $nama=$i['anggota_nama'];
          					   $jenkel=$i['anggota_jenkel'];
                       $no_telp=$i['anggota_no_telp'];
                       $alamat=$i['anggota_alamat'];
          					   $prodi_id=$i['anggota_prodi_id'];
                       $prodi_nama=$i['prodi_nama'];
                       $angkatan=$i['anggota_angkatan'];
                       $photo=$i['anggota_photo'];

                    ?>
                <tr>
                  <?php if(empty($photo)):?>
                  <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/member/user_blank.png';?>"></td>
                  <?php else:?>
                  <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/member/'.$photo;?>"></td>
                  <?php endif;?>
                  <td><?php echo $nim;?></td>
        				  <td><?php echo $nama;?></td>
                  <?php if($jenkel=='L'):?>
                  <td>Laki-Laki</td>
                  <?php else:?>
                  <td>Perempuan</td>
                  <?php endif;?>
                  <td><?php echo $no_telp;?></td>
                  <td><?php echo $alamat;?></td>
                  <td><?php echo $prodi_nama;?></td>
                  <td><?php echo $angkatan;?></td>
                  <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                  </td>
                </tr>
				<?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Anggota-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Anggota</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/anggota/simpan_anggota'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">NIM</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnim" class="form-control" id="inputAnggota" placeholder="Nomor Induk Mahasiswa" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputAnggota" placeholder="Nama" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="L" name="xjenkel" checked>
                                                <label for="inlineRadio1"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio2" value="P" name="xjenkel">
                                                <label for="inlineRadio2"> Perempuan </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">No. Telephone</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_telp" class="form-control" id="inputAnggota" placeholder="Nomor Telephone" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" class="form-control" id="inputAnggota" placeholder="Alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Program Studi</label>
                                        <div class="col-sm-7">
                                          <select name="xprodi" class="form-control" required>
                                            <option value="">-Pilih Program Studi-</option>
                                            <?php
                                                foreach ($prodi->result_array() as $k) {
                                                  $id_prodi=$k['prodi_id'];
                                                  $nm_prodi=$k['prodi_nama'];

                                            ?>
                                            <option value="<?php echo $id_prodi;?>"><?php echo $nm_prodi;?></option>
                                            <?php } ?>
                                          </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Angkatan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xangkatan" class="form-control" id="inputAnggota" placeholder="Tahun Angkatan" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Photo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

  <!--Modal Edit Anggota-->
  <?php foreach ($data->result_array() as $i) :
              $id=$i['anggota_id'];
              $nim=$i['anggota_nim'];
              $nama=$i['anggota_nama'];
              $jenkel=$i['anggota_jenkel'];
              $no_telp=$i['anggota_no_telp'];
              $alamat=$i['anggota_alamat'];
              $prodi_id=$i['anggota_prodi_id'];
              $angkatan=$i['anggota_angkatan'];
              $photo=$i['anggota_photo'];
            ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Anggota</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/anggota/update_anggota'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                                <input type="hidden" value="<?php echo $photo;?>" name="gambar">
                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">NIM</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnim" value="<?php echo $nim;?>" class="form-control" id="inputAnggota" placeholder="Nomor Induk Mahasiswa" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputAnggota" placeholder="Nama Lengkap" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
                                          <?php if($jenkel=='L'):?>
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio3" value="L" name="xjenkel" checked>
                                                <label for="inlineRadio3"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio4" value="P" name="xjenkel">
                                                <label for="inlineRadio4"> Perempuan </label>
                                            </div>
                                          <?php else:?>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio5" value="L" name="xjenkel">
                                                <label for="inlineRadio5"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio6" value="P" name="xjenkel" checked>
                                                <label for="inlineRadio6"> Perempuan </label>
                                            </div>
                                          <?php endif;?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">No. Telephone</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_telp" value="<?php echo $no_telp;?>" class="form-control" id="inputAnggota" placeholder="Nomor Telephone" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" value="<?php echo $alamat;?>" class="form-control" id="inputAnggota" placeholder="Alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Program Studi</label>
                                        <div class="col-sm-7">
                                          <select name="xprodi" class="form-control" required>
                                            <option value="">-Pilih Program Studi-</option>
                                            <?php
                                                foreach ($prodi->result_array() as $k) {
                                                  $id_prodi=$k['prodi_id'];
                                                  $nm_prodi=$k['prodi_nama'];

                                            ?>
                                            <?php if($id_prodi==$prodi_id):?>
                                              <option value="<?php echo $id_prodi;?>" selected><?php echo $nm_prodi;?></option>
                                            <?php else:?>
                                              <option value="<?php echo $id_prodi;?>"><?php echo $nm_prodi;?></option>
                                            <?php endif;?>
                                            <?php } ?>
                                          </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Angkatan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xangkatan" value="<?php echo $angkatan;?>" class="form-control" id="inputAnggota" placeholder="Tahun Angkatan" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputAnggota" class="col-sm-4 control-label">Photo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>


  <!--Modal Hapus Anggota-->
	<?php foreach ($data->result_array() as $i) :
              $id=$i['anggota_id'];
              $nim=$i['anggota_nim'];
              $nama=$i['anggota_nama'];
              $jenkel=$i['anggota_jenkel'];
              $no_telp=$i['anggota_no_telp'];
              $alamat=$i['anggota_alamat'];
              $prodi_id=$i['anggota_prodi_id'];
              $angkatan=$i['anggota_angkatan'];
              $photo=$i['anggota_photo'];
            ?>

        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Anggota</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/anggota/hapus_anggota'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							       <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                     <input type="hidden" value="<?php echo $photo;?>" name="gambar">
                            <p>Apakah Anda yakin mau menghapus anggota <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>




