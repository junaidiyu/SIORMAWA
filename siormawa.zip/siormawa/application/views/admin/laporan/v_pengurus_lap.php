<?php
//include 'koneksi.php';
require('application/libraries/fpdf1.8/fpdf.php');

define('FPDF_FONTPATH', 'application/libraries/fpdf1.8/font/');

$pdf = new FPDF("L","cm","A4");

$pdf->SetMargins(2,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','B',11);
$pdf->Image('theme/images/ESC.png',1,1,2,2);
$pdf->SetX(4);            
$pdf->MultiCell(20.5,0.5,'ENGLISH STUDY CLUB POLITEKNIK NEGERI SAMBAS',0,'C');    
$pdf->SetFont('Times','B',10);
$pdf->SetX(4);
$pdf->MultiCell(19.5,0.5,'JL.Raya Sekangkung, Kabupaten Sambas',0,'C');
$pdf->SetX(4);
$pdf->MultiCell(20.5,0.5,'website: www.escpoltesa.com email: escpoltesa@gmail.com',0,'C');
$pdf->Line(1,3.1,28.5,3.1);
$pdf->SetLineWidth(0.1);      
$pdf->Line(1,3.2,28.5,3.2);   
$pdf->SetLineWidth(0);
$pdf->ln(1);
$pdf->SetFont('Times','B',14);
$pdf->Cell(25.5,0.7,"Laporan Data Pengurus",0,10,'C');
$pdf->ln(1);
$pdf->SetFont('Times','B',10);
$pdf->Cell(4,0.7,"Di cetak pada : ".date("d/F/Y"),0,0,'C');
$pdf->ln(1);
$pdf->SetFont('Times','B',10);
$pdf->Cell(1, 0.8, 'No', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'NIM', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Nama', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Jenis Kelamin', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'No HP', 1, 0, 'C');
$pdf->Cell(6, 0.8, 'Alamat', 1, 0, 'C');
$pdf->Cell(3, 0.8, 'Program Studi', 1, 0, 'C');
$pdf->Cell(4, 0.8, 'Angkatan', 1, 1, 'C');
$pdf->SetFont('Times','',10);
$no=1;
//$query=mysqli_query("select * from peserta");
$query=$this->db->query("SELECT tbl_pengurus.*,prodi_kode,prodi_nama FROM tbl_pengurus JOIN tbl_prodi ON pengurus_prodi_id=prodi_id");
foreach ($query->result_array() as $lihat) :
	$pdf->Cell(1, 0.8, $no , 1, 0, 'C');
	$pdf->Cell(3, 0.8, $lihat['pengurus_nim'],1, 0, 'C');
	$pdf->Cell(4, 0.8, $lihat['pengurus_nama'], 1, 0,'L');
	$pdf->Cell(3, 0.8, $lihat['pengurus_jenkel'], 1, 0,'L');
	$pdf->Cell(3, 0.8, $lihat['pengurus_no_telp'],1, 0, 'C');
	$pdf->Cell(6, 0.8, $lihat['pengurus_alamat'], 1, 0,'C');
	$pdf->Cell(3, 0.8, $lihat['prodi_kode'], 1, 0,'C');
	$pdf->Cell(4, 0.8, $lihat['pengurus_angkatan'], 1, 1,'C');

	$no++;
endforeach;

$pdf->Output("laporan_data_pengurus.pdf","I");

?>