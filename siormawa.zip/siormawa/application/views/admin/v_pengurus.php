  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Pengurus
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pengurus</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Pengurus</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/pengurus_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
          					<th>Photo</th>
          					<th>NIM</th>
          					<th>Nama</th>
                    <th>Jenis Kelamin</th>
          					<th>Nomor Telephone</th>
                    <th>Alamat</th>
                    <th>Jabatan</th>
                    <th>Program Studi</th>
                    <th>Angkatan</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
          				<?php
          					$no=0;
          					foreach ($data->result_array() as $i) :
          					   $no++;
          					   $id=$i['pengurus_id'];
          					   $nim=$i['pengurus_nim'];
          					   $nama=$i['pengurus_nama'];
          					   $jenkel=$i['pengurus_jenkel'];
          					   $no_telp=$i['pengurus_no_telp'];
          					   $alamat=$i['pengurus_alamat'];
                       $jabatan_id=$i['pengurus_jabatan_id'];
                       $jabatan_nama=$i['jabatan_nama'];
                       $prodi_id=$i['pengurus_prodi_id'];
                       $prodi_nama=$i['prodi_nama'];
                       $photo=$i['pengurus_photo'];
                       $angkatan=$i['pengurus_angkatan'];

                    ?>
                <tr>
                  <?php if(empty($photo)):?>
                  <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/organizer/user_blank.png';?>"></td>
                  <?php else:?>
                  <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/organizer/'.$photo;?>"></td>
                  <?php endif;?>
                  <td><?php echo $nim;?></td>
        				  <td><?php echo $nama;?></td>
                  <?php if($jenkel=='L'):?>
                  <td>Laki-Laki</td>
                  <?php else:?>
                  <td>Perempuan</td>
                  <?php endif;?>
                  <td><?php echo $no_telp;?></td>
                  <td><?php echo $alamat;?></td>
                  <td><?php echo $jabatan_nama;?></td>
                  <td><?php echo $prodi_nama;?></td>
                  <td><?php echo $angkatan;?></td>
                  <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                  </td>
                </tr>
			   	        <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Pengurus-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Pengurus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/pengurus/simpan_pengurus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">NIM</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnim" class="form-control" id="inputPengurus" placeholder="Nomor Induk Mahasiswa" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputPengurus" placeholder="Nama" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="L" name="xjenkel" checked>
                                                <label for="inlineRadio1"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio2" value="P" name="xjenkel">
                                                <label for="inlineRadio2"> Perempuan </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Nomor Telephone</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_telp" class="form-control" id="inputPengurus" placeholder="Nomor Telephone" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" class="form-control" id="inputPengurus" placeholder="Alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Jabatan</label>
                                        <div class="col-sm-7">
                                             <input type="text" name="xjabatan" class="form-control" id="inputPengurus" placeholder="Jabatan" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Program Studi</label>
                                        <div class="col-sm-7">
                                              <input type="text" name="xprodi" class="form-control" id="inputPengurus" placeholder="Program Studi" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Angkatan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xangkatan" class="form-control" id="inputPengurus" placeholder="Tahun Angkatan" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Photo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

  <!--Modal Edit Pengurus-->
  <?php foreach ($data->result_array() as $i) :
              $id=$i['pengurus_id'];
              $nim=$i['pengurus_nim'];
              $nama=$i['pengurus_nama'];
              $jenkel=$i['pengurus_jenkel'];
              $no_telp=$i['pengurus_no_telp'];
              $alamat=$i['pengurus_alamat'];
              $jabatan_id=$i['pengurus_jabatan_id'];
              $prodi_id=$i['pengurus_prodi_id'];
              $angkatan=$i['pengurus_angkatan'];
              $photo=$i['pengurus_photo'];
            ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Pengurus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/pengurus/update_pengurus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                                <input type="hidden" value="<?php echo $photo;?>" name="gambar">
                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">NIM</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnim" value="<?php echo $nim;?>" class="form-control" id="inputPengurus" placeholder="NIM" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputPengurus" placeholder="Nama" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
                                          <?php if($jenkel=='L'):?>
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio3" value="L" name="xjenkel" checked>
                                                <label for="inlineRadio3"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio4" value="P" name="xjenkel">
                                                <label for="inlineRadio4"> Perempuan </label>
                                            </div>
                                          <?php else:?>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio5" value="L" name="xjenkel">
                                                <label for="inlineRadio5"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio6" value="P" name="xjenkel" checked>
                                                <label for="inlineRadio6"> Perempuan </label>
                                            </div>
                                          <?php endif;?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Nomor Telephone</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_telp" value="<?php echo $no_telp;?>" class="form-control" id="inputPengurus" placeholder="Nomor Telephone" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Alamat</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat" value="<?php echo $alamat;?>" class="form-control" id="inputPengurus" placeholder="Alamat" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Jabatan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xjabatan" value="<?php echo $jabatan_id;?>" class="form-control" id="inputPengurus" placeholder="Jabatan" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Program Studi</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xprodi" value="<?php echo $prodi_id;?>" class="form-control" id="inputPengurus" placeholder="Program Studi" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Angkatan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xangkatan" value="<?php echo $angkatan;?>" class="form-control" id="inputPengurus" placeholder="Angkatan" required>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label for="inputPengurus" class="col-sm-4 control-label">Photo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>
	<!--Modal Delete Pengurus-->

	<?php foreach ($data->result_array() as $i) :
              $id=$i['pengurus_id'];
              $nim=$i['pengurus_nim'];
              $nama=$i['pengurus_nama'];
              $jenkel=$i['pengurus_jenkel'];
              $no_telp=$i['pengurus_no_telp'];
              $alamat=$i['pengurus_alamat'];
              $jabatan_id=$i['pengurus_jabatan_id'];
              $prodi_id=$i['pengurus_prodi_id'];
              $angkatan=$i['pengurus_angkatan'];
              $photo=$i['pengurus_photo'];
            ?>
	<!--Modal Hapus Penurus-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Pengurus</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/pengurus/hapus_pengurus'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							       <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                     <input type="hidden" value="<?php echo $photo;?>" name="gambar">
                            <p>Apakah Anda yakin mahu menghapus pengurus <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

