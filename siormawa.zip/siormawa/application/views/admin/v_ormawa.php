  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Organisasi Mahasiswa
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Ormawa</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Ormawa</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/ormawa_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Print</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Logo</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Jenis</th>
                    <th>Kampus</th>
                    <th>Tanggal Input</th>
                    <th>Terakhir Diupdate</th>
                    <th>Author</th>
                    <th style="text-align:right;">Opsi</th>
                </tr>
                </thead>
                <tbody>
          				<?php
          					$no=0;
          					foreach ($data->result_array() as $i) :
          					   $no++;
          					   $id=$i['ormawa_id'];
          					   $kode=$i['ormawa_kode'];
          					   $nama=$i['ormawa_nama'];
          					   $logo=$i['ormawa_logo'];
                       $no_sk=$i['ormawa_no_sk'];
                       $tgl_sk=$i['ormawa_tgl_sk'];
                       $jenis=$i['jenis_kode'];
                       $kampus=$i['kampus_kode'];
                       $author=$i['ormawa_author'];
                       $tgl_input=$i['ormawa_tgl_input'];
                       $tgl_update=$i['ormawa_tgl_update'];
                    ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <?php if(empty($logo)):?>
                      <td></td>
                      <?php else:?>
                      <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/ormawa/'.$logo;?>"></td>
                      <?php endif;?>
                      <td><?php echo $kode;?></td>
                      <td><?php echo $nama;?></td>
                      <td><?php echo $jenis;?></td>
                      <td><?php echo $kampus;?></td>
                      <td><?php echo $tgl_input;?></td>
                      <td><?php echo $tgl_update;?></td>
                      <td><?php echo $author;?></td>
                      <td style="text-align:right;">
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-search-plus"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalEdit<?php echo $id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                      </td>
                    </tr>
			   	       <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Ormawa-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Ormawa</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/ormawa/simpan_ormawa'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Kode</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xkode" class="form-control" id="inputOrmawa" placeholder="Kode Ormawa" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputOrmawa" placeholder="Nama Ormawa" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Nomor SK</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_sk" class="form-control" id="inputOrmawa" placeholder="Nomor SK" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Tanggal SK</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtgl_sk" class="form-control" id="inputOrmawa" placeholder="Tanggal SK" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">logo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="xlogo"/>
                                        </div>
                                    </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary btn-flat" id="simpan">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

  <!--Modal Edit Ormawa-->
  <?php foreach ($data->result_array() as $i) :
              $id=$i['ormawa_id'];
              $kode=$i['ormawa_kode'];
              $nama=$i['ormawa_nama'];
              $logo=$i['ormawa_logo'];
              $no_sk=$i['ormawa_no_sk'];
              $tgl_sk=$i['ormawa_tgl_sk'];
              $author=$i['ormawa_author'];
              $tgl_input=$i['ormawa_tgl_input'];
              $tgl_update=$i['ormawa_tgl_update'];
  ?>

        <div class="modal fade" id="ModalEdit<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Ormawa</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/ormawa/update_ormawa'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                                <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                                <input type="hidden" value="<?php echo $logo;?>" name="gambar">
                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Kode</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xkode" value="<?php echo $kode;?>" class="form-control" id="inputOrmawa" placeholder="KODE" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" value="<?php echo $nama;?>" class="form-control" id="inputOrmawa" placeholder="Nama" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Nomor SK</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xno_sk" value="<?php echo $no_sk;?>" class="form-control" id="inputOrmawa" placeholder="Nomor SK" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Tanggal SK</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtgl_sk" value="<?php echo $tgl_sk;?>" class="form-control" id="inputOrmawa" placeholder="Tanggal SK" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputOrmawa" class="col-sm-4 control-label">Logo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="xlogo"/>
                                        </div>
                                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Save</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
  <?php endforeach;?>
	<!--Modal Delete Ormawa-->

	<?php foreach ($data->result_array() as $i) :
              $id=$i['ormawa_id'];
              $kode=$i['ormawa_kode'];
              $nama=$i['ormawa_nama'];
              $logo=$i['ormawa_logo'];
              $no_sk=$i['ormawa_no_sk'];
              $tgl_sk=$i['ormawa_tgl_sk'];
              $author=$i['ormawa_author'];
              $tgl_input=$i['ormawa_tgl_input'];
              $tgl_update=$i['ormawa_tgl_update'];
  ?>
	<!--Modal Hapus Ormawa-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Ormawa</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/ormawa/hapus_ormawa'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							       <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                     <input type="hidden" value="<?php echo $logo;?>" name="gambar">
                            <p>Apakah Anda yakin mahu menghapus ormawa <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Delete</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

