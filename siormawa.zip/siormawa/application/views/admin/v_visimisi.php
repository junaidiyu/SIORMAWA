  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Visi Misi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Visi Misi</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            <div class="box-header">
              <a class="btn btn-success btn-flat" data-toggle="modal" data-target="#myModal"><span class="fa fa-plus"></span> Add Visi Misi</a><a style="margin-bottom:10px" href="<?php echo base_url().'admin/laporan/visimisi_lap' ?>" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-striped" style="font-size:13px;">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Gambar</th>
                    <th>Deskripsi</th>
                    <th>Status</th>
                    <th>Author</th>
                    <th>Tanggal Input</th>
                    <th style="text-align:right;">Aksi</th>
                </tr>
                </thead>
                <tbody>
          				<?php
          					$no=0;
          					foreach ($data->result_array() as $i) :
          					   $no++;

          					   $id=$i['profil_id'];
          					   $nama=$i['profil_nama'];
          					   $detail=$i['profil_detail'];
          					   $photo=$i['profil_photo'];
                       $jenis=$i['profil_jenis'];
                       $status=$i['profil_status'];
                       $author=$i['profil_author'];
                       $tgl_input=$i['profil_tgl_input'];
                    ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $nama;?></td>
                      <?php if(empty($photo)):?>
                      <td></td>
                      <?php else:?>
                      <td><img width="40" height="40" class="img-circle" src="<?php echo base_url().'assets/images/profile/'.$photo;?>"></td>
                      <?php endif;?>
                      <td><?php echo $detail;?></td>
                      <td><?php echo $status;?></td>
                      <td><?php echo $author;?></td>
                      <td><?php echo $tgl_input;?></td>
                      <td style="text-align:right;">
                        <a class="btn" href="<?php echo base_url().'admin/visimisi/get_edit/'.$id;?>"><span class="fa fa-pencil"></span></a>
                        <a class="btn" data-toggle="modal" data-target="#ModalHapus<?php echo $id;?>"><span class="fa fa-trash"></span></a>
                      </td>
                    </tr>
			   	       <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


    <!--Modal Add Visi Misi-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Visi Misi</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/visimisi/simpan_visimisi'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputVisi Misi" class="col-sm-2 control-label">Judul</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="xnama" class="form-control" id="inputVisi Misi" placeholder="Judul Visi Misi" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="inputVisi Misi" class="col-sm-2 control-label">Gambar</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>

                                    <!--Box-->
                                    <div class="box box-danger">
                                      <div class="box-header">
                                        <h2 class="box-title">Deskripsi</h2>
                                      </div>
                                      <div class="box-body">

                                       <textarea id="ckeditor" name="xdetail" required></textarea>

                                      </div>
                                      <!-- /.box-body -->
                                    </div>
                                    <!-- /.box -->

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


	<!--Modal Delete Visi Misi-->
	<?php foreach ($data->result_array() as $i) :
              $id=$i['profil_id'];
              $nama=$i['profil_nama'];
              $detail=$i['profil_detail'];
              $photo=$i['profil_photo'];
            ?>
	<!--Modal Hapus Visi Misi-->
        <div class="modal fade" id="ModalHapus<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Visi Misi</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/visimisi/hapus_visimisi'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							       <input type="hidden" name="kode" value="<?php echo $id;?>"/>
                     <input type="hidden" value="<?php echo $photo;?>" name="gambar">
                            <p>Apakah Anda yakin mahu menghapus visimisi <b><?php echo $nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

