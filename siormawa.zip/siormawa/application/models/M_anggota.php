<?php 
class M_anggota extends CI_Model{

	function get_all_anggota(){
		$hsl=$this->db->query("SELECT tbl_anggota.*,prodi_kode,prodi_nama FROM tbl_anggota JOIN tbl_prodi ON anggota_prodi_id=prodi_id");
		return $hsl;
	}

	function simpan_anggota($nim,$nama,$jenkel,$no_telp,$alamat,$prodi,$angkatan,$photo){
		$hsl=$this->db->query("INSERT INTO tbl_anggota (anggota_nim,anggota_nama,anggota_jenkel,anggota_no_telp,anggota_alamat,anggota_prodi_id,anggota_angkatan,anggota_photo) VALUES ('$nim','$nama','$jenkel','$no_telp','$alamat','$prodi','$angkatan','$photo')");
		return $hsl;
	}
	function simpan_anggota_tanpa_img($nim,$nama,$jenkel,$no_telp,$alamat,$prodi,$angkatan){
		$hsl=$this->db->query("INSERT INTO tbl_anggota (anggota_nim,anggota_nama,anggota_jenkel,anggota_no_telp,anggota_alamat,anggota_prodi_id,anggota_angkatan) VALUES ('$nim','$nama','$jenkel','$no_telp','$alamat','$prodi','$angkatan')");
		return $hsl;
	}

	function update_anggota($kode,$nim,$nama,$jenkel,$no_telp,$alamat,$prodi,$angkatan,$photo){
		$hsl=$this->db->query("UPDATE tbl_anggota SET anggota_nim='$nim',anggota_nama='$nama',anggota_jenkel='$jenkel',anggota_no_telp='$no_telp',anggota_alamat='$alamat',anggota_prodi_id='$prodi',anggota_angkatan='$angkatan',anggota_photo='$photo' WHERE anggota_id='$kode'");
		return $hsl;
	}
	function update_anggota_tanpa_img($kode,$nim,$nama,$jenkel,$no_telp,$alamat,$prodi,$angkatan){
		$hsl=$this->db->query("UPDATE tbl_anggota SET anggota_nim='$nim',anggota_nama='$nama',anggota_jenkel='$jenkel',anggota_no_telp='$no_telp',anggota_alamat='$alamat',anggota_prodi_id='$prodi',anggota_angkatan='$angkatan' WHERE anggota_id='$kode'");
		return $hsl;
	}
	function hapus_anggota($kode){
		$hsl=$this->db->query("DELETE FROM tbl_anggota WHERE anggota_id='$kode'");
		return $hsl;
	}

	//front-end
	function anggota(){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_anggota.*,prodi_kode,prodi_nama FROM tbl_anggota JOIN tbl_prodi ON anggota_prodi_id=prodi_id WHERE anggota_ormawa_id='$ormawa'");
		return $hsl;
	}
	function anggota_perpage($offset,$limit){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_anggota.*,prodi_kode,prodi_nama FROM tbl_anggota JOIN tbl_prodi ON anggota_prodi_id=prodi_id WHERE anggota_ormawa_id='$ormawa' limit $offset,$limit");
		return $hsl;
	}

}