<?php
class M_prodi extends CI_Model{

	function get_all_prodi(){
		$hsl=$this->db->query("SELECT *,jurusan_kode,jurusan_nama FROM tbl_prodi JOIN tbl_jurusan ON prodi_jurusan_id=jurusan_id");
		return $hsl;
	}

	function simpan_prodi($kode,$nama,$author){
		$hsl=$this->db->query("INSERT INTO tbl_prodi (prodi_kode,prodi_nama,prodi_author) VALUES ('$kode','$nama','$author')");
		return $hsl;
	}

	function update_prodi($k,$kode,$nama,$author){
		$hsl=$this->db->query("UPDATE tbl_prodi SET prodi_kode='$kode',prodi_nama='$nama',prodi_author='$author' WHERE prodi_id='$k'");
		return $hsl;
	}
	function hapus_prodi($k){
		$hsl=$this->db->query("DELETE FROM tbl_prodi WHERE prodi_id='$k'");
		return $hsl;
	}

	//front-end
	
}