<?php
class M_kontak extends CI_Model{
	//Kontak
	function get_all_Kontak(){
		$hsl=$this->db->query("SELECT * FROM tbl_kontak");
		return $hsl;
	}

	function simpan_kontak($nama,$email,$wa,$fb,$ig,$yt,$author){
		$hsl=$this->db->query("INSERT INTO tbl_kontak (kontak_nama,kontak_email,kontak_wa,kontak_fb,kontak_ig,kontak_yt,kontak_author) VALUES ('$nama','$email','$wa','$fb','$ig','yt','$author')");
		return $hsl;
	}

	function update_kontak($k,$nama,$email,$wa,$fb,$ig,$yt,$author){
		$hsl=$this->db->query("UPDATE tbl_kontak SET kontak_nama='$nama',kontak_email='$email',kontak_wa='$wa',kontak_fb='$fb',kontak_ig='$ig',kontak_yt='$yt',kontak_author='$author' WHERE kontak_id='$k'");
		return $hsl;
	}

	function hapus_kontak($k){
		$hsl=$this->db->query("DELETE FROM tbl_kontak WHERE kontak_id='$k'");
		return $hsl;
	}
	

	//Kontak Frontend
	function get_kontak(){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT * FROM tbl_kontak WHERE kontak_ormawa_id='$ormawa'");
		return $hsl;
	}


	//inbox
	function kirim_pesan($nama,$email,$kontak,$pesan){
		$hsl=$this->db->query("INSERT INTO tbl_inbox(inbox_nama,inbox_email,inbox_kontak,inbox_pesan) VALUES ('$nama','$email','$kontak','$pesan')");
		return $hsl;
	}

	function get_all_inbox(){
		$hsl=$this->db->query("SELECT tbl_inbox.*,DATE_FORMAT(inbox_tanggal,'%d %M %Y') AS tanggal FROM tbl_inbox ORDER BY inbox_id DESC");
		return $hsl;
	}

	function hapus_inbox($kode){
		$hsl=$this->db->query("DELETE FROM tbl_inbox WHERE inbox_id='$kode'");
		return $hsl;
	}

	function update_status_inbox(){
		$hsl=$this->db->query("UPDATE tbl_inbox SET inbox_status='0'");
		return $hsl;
	}
}