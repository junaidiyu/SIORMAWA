<?php
class M_jenis extends CI_Model{

	function get_all_jenis(){
		$hsl=$this->db->query("SELECT * FROM tbl_jenis");
		return $hsl;
	}

	function simpan_jenis($kode,$nama,$author){
		$hsl=$this->db->query("INSERT INTO tbl_jenis (jenis_kode,jenis_nama,jenis_author) VALUES ('$kode','$nama','$author')");
		return $hsl;
	}

	function update_jenis($k,$kode,$nama,$author){
		$hsl=$this->db->query("UPDATE tbl_jenis SET jenis_kode='$kode',jenis_nama='$nama',jenis_author='$author' WHERE jenis_id='$k'");
		return $hsl;
	}
	function hapus_jenis($k){
		$hsl=$this->db->query("DELETE FROM tbl_jenis WHERE jenis_id='$k'");
		return $hsl;
	}

	//front-end
	
}