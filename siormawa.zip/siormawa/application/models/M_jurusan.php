<?php 
class M_jurusan extends CI_Model{

	function get_all_jurusan(){
		$hsl=$this->db->query("SELECT tbl_jurusan.* FROM tbl_jurusan");
		return $hsl;
	}

	function simpan_jurusan($kode,$nama,$author){
		$hsl=$this->db->query("INSERT INTO tbl_jurusan (jurusan_kode,jurusan_nama,jurusan_author) VALUES ('$kode','$nama','$author')");
		return $hsl;
	}

	function update_jurusan($k,$kode,$nama,$author){
		$hsl=$this->db->query("UPDATE tbl_jurusan SET jurusan_kode='$kode',jurusan_nama='$nama',jurusan_author='$author' WHERE jurusan_id='$k'");
		return $hsl;
	}
	function hapus_jurusan($k){
		$hsl=$this->db->query("DELETE FROM tbl_jurusan WHERE jurusan_id='$k'");
		return $hsl;
	}

	//front-end
	

}