<?php
class M_tema extends CI_Model{

	function get_all_tema(){
		$hsl=$this->db->query("select * from tbl_tema");
		return $hsl;
	}
	function simpan_tema($tema){
		$hsl=$this->db->query("insert into tbl_tema(tema_nama) values('$tema')");
		return $hsl;
	}
	function update_tema($kode,$tema){
		$hsl=$this->db->query("update tbl_tema set tema_nama='$tema' where tema_id='$kode'");
		return $hsl;
	}
	function hapus_tema($kode){
		$hsl=$this->db->query("delete from tbl_tema where tema_id='$kode'");
		return $hsl;
	}
	
	function get_tema_byid($tema_id){
		$hsl=$this->db->query("select * from tbl_tema where tema_id='$tema_id'");
		return $hsl;
	}

	//Frontend
	function get_tema(){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("select * from tbl_tema where tema_ormawa_id='$ormawa'");
		return $hsl;
	}

}