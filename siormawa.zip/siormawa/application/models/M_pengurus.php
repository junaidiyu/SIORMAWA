<?php 
class M_pengurus extends CI_Model{

	function get_all_pengurus(){
		$hsl=$this->db->query("SELECT tbl_pengurus.*,jabatan_nama,prodi_kode,prodi_nama FROM tbl_pengurus JOIN tbl_jabatan ON pengurus_jabatan_id=jabatan_id JOIN tbl_prodi ON pengurus_prodi_id=prodi_id");
		return $hsl;
	}
	function get_all_pengurus2(){
		$ormawa=$this->session->userdata('ormawa_id');
		$hsl=$this->db->query("SELECT tbl_pengurus.*,jabatan_nama,prodi_kode,prodi_nama FROM tbl_pengurus JOIN tbl_jabatan ON pengurus_jabatan_id=jabatan_id JOIN tbl_prodi ON pengurus_prodi_id=prodi_id WHERE pengurus_ormawa_id='$ormawa'");
		return $hsl;
	}

	function simpan_pengurus($nim,$nama,$jenkel,$no_telp,$alamat,$jabatan,$prodi,$angkatan,$photo){
		$hsl=$this->db->query("INSERT INTO tbl_pengurus (pengurus_nim,pengurus_nama,pengurus_jenkel,pengurus_no_telp,pengurus_alamat,pengurus_jabatan_id,pengurus_prodi_id,pengurus_angkatan,pengurus_photo) VALUES ('$nim','$nama','$jenkel','$no_telp','$alamat','$jabatan','$prodi','$angkatan','$photo')");
		return $hsl;
	}
	function simpan_pengurus_tanpa_img($nim,$nama,$jenkel,$no_telp,$alamat,$jabatan,$prodi,$angkatan){
		$hsl=$this->db->query("INSERT INTO tbl_pengurus (pengurus_nim,pengurus_nama,pengurus_jenkel,pengurus_no_telp,pengurus_alamat,pengurus_jabatan_id,pengurus_prodi_id,pengurus_angkatan) VALUES ('$nim','$nama','$jenkel','$no_telp','$alamat','$jabatan','$prodi','$angkatan')");
		return $hsl;
	}

	function update_pengurus($kode,$nim,$nama,$jenkel,$no_telp,$alamat,$jabatan,$prodi,$angkatan,$photo){
		$hsl=$this->db->query("UPDATE tbl_pengurus SET pengurus_nim='$nim',pengurus_nama='$nama',pengurus_jenkel='$jenkel',pengurus_no_telp='$no_telp',pengurus_alamat='$alamat',pengurus_jabatan_id='$jabatan',pengurus_prodi_id='$prodi',pengurus_angkatan='$angkatan',pengurus_photo='$photo' WHERE pengurus_id='$kode'");
		return $hsl;
	}
	function update_pengurus_tanpa_img($kode,$nim,$nama,$jenkel,$no_telp,$alamat,$jabatan,$prodi,$angkatan){
		$hsl=$this->db->query("UPDATE tbl_pengurus SET pengurus_nim='$nim',pengurus_nama='$nama',pengurus_jenkel='$jenkel',pengurus_no_telp='$no_telp',pengurus_alamat='$alamat',pengurus_jabatan_id='$jabatan',pengurus_prodi_id='$prodi',pengurus_angkatan='$angkatan' WHERE pengurus_id='$kode'");
		return $hsl;
	}
	function hapus_pengurus($kode){
		$hsl=$this->db->query("DELETE FROM tbl_pengurus WHERE pengurus_id='$kode'");
		return $hsl;
	}

	//front-end
	function pengurus(){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_pengurus.*,jabatan_nama,prodi_kode,prodi_nama FROM tbl_pengurus JOIN tbl_jabatan ON pengurus_jabatan_id=jabatan_id JOIN tbl_prodi ON pengurus_prodi_id=prodi_id WHERE pengurus_ormawa_id='$ormawa'");
		return $hsl;
	}
	function pengurus_perpage($offset,$limit){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_pengurus.*,jabatan_nama,prodi_kode,prodi_nama FROM tbl_pengurus JOIN tbl_jabatan ON pengurus_jabatan_id=jabatan_id JOIN tbl_prodi ON pengurus_prodi_id=prodi_id WHERE pengurus_ormawa_id='$ormawa' limit $offset,$limit");
		return $hsl;
	}

}