<?php 
class M_kampus extends CI_Model{

	function get_all_kampus(){
		$hsl=$this->db->query("SELECT tbl_kampus.* FROM tbl_kampus");
		return $hsl;
	}
	function get_all_kampus2(){
		$kampus=$this->session->userdata('kampus_id');
		$hsl=$this->db->query("SELECT tbl_kampus.* FROM tbl_kampus WHERE kampus_id='$kampus'");
		return $hsl;
	}

	function get_kampus_user(){
		$kampus=$this->session->userdata('kampus_id');
		$hsl=$this->db->query("SELECT tbl_kampus.* FROM tbl_kampus WHERE kampus_id='$kampus'");
		return $hsl;
	}

	function simpan_kampus($kode,$nama,$email,$alamat,$website,$logo,$author){
		$hsl=$this->db->query("INSERT INTO tbl_kampus (kampus_kode,kampus_nama,kampus_email,kampus_alamat,kampus_website,kampus_logo,kampus_author) VALUES ('$kode','$nama','$email','$alamat','$website','$photo','$author')");
		return $hsl;
	}

	function simpan_kampus_tanpa_img($kode,$nama,$email,$alamat,$website,$author){
		$hsl=$this->db->query("INSERT INTO tbl_kampus (kampus_kode,kampus_nama,kampus_email,kampus_alamat,kampus_website,kampus_author) VALUES ('$kode','$nama','$email','$alamat','$website','$author')");
		return $hsl;
	}

	function update_kampus($k,$kode,$nama,$email,$alamat,$website,$logo,$author){
		$hsl=$this->db->query("UPDATE tbl_kampus SET kampus_kode='$kode',kampus_nama='$nama',kampus_email='$email',kampus_alamat='$alamat',kampus_website='$website',kampus_logo='$logo',kampus_author='$author' WHERE kampus_id='$k'");
		return $hsl;
	}
	function update_kampus_tanpa_img($k,$kode,$nama,$email,$alamat,$website,$author){
		$hsl=$this->db->query("UPDATE tbl_kampus SET kampus_kode='$kode',kampus_nama='$nama',kampus_email='$email',kampus_alamat='$alamat',kampus_website='$website',kampus_author='$author' WHERE kampus_id='$k'");
		return $hsl;
	}
	function hapus_kampus($k){
		$hsl=$this->db->query("DELETE FROM tbl_kampus WHERE kampus_id='$k'");
		return $hsl;
	}

	//front-end
	function kampus(){
		$kampus=$this->session->userdata('kampus_id2');
		$hsl=$this->db->query("SELECT tbl_kampus.* FROM tbl_kampus WHERE kampus_id='$kampus'");
		return $hsl;
	}
	function kampus_perpage($offset,$limit){
		$kampus=$this->session->userdata('kampus_id2');
		$hsl=$this->db->query("SELECT tbl_kampus.* FROM tbl_kampus WHERE kampus_id='$kampus' limit $offset,$limit");
		return $hsl;
	}

}