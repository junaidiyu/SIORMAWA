<?php 
class M_profil extends CI_Model{

	function get_all_profil($profil){
		$hsl=$this->db->query("SELECT tbl_profil.* FROM tbl_profil WHERE profil_jenis='$profil'");
		return $hsl;
	}

	function get_all_profil2($profil){
		$ormawa=$this->session->userdata('ormawa_id');
		$hsl=$this->db->query("SELECT tbl_profil.* FROM tbl_profil WHERE profil_ormawa_id='$ormawa' AND profil_jenis='$profil'");
		return $hsl;
	}
	function get_profil_by_kode($profil,$k){
		$hsl=$this->db->query("SELECT tbl_profil.* FROM tbl_profil WHERE profil_jenis='$profil' AND profil_id='$k'");
		return $hsl;
	}

	function simpan_profil($nama,$detail,$photo,$profil,$author){
		$hsl=$this->db->query("INSERT INTO tbl_profil (profil_nama,profil_detail,profil_photo,profil_jenis,profil_author) VALUES ('$nama','$detail','$photo','$profil','$author')");
		return $hsl;
	}

	function simpan_profil_tanpa_img($nama,$detail,$profil,$author){
		$hsl=$this->db->query("INSERT INTO tbl_profil (profil_nama,profil_detail,profil_jenis,profil_author) VALUES ('$nama','$detail','$profil','$author')");
		return $hsl;
	}

	function update_profil($k,$nama,$detail,$photo,$status,$author){
		$hsl=$this->db->query("UPDATE tbl_profil SET profil_nama='$nama',profil_detail='$detail',profil_photo='$photo',profil_status='$status',profil_author='$author' WHERE profil_id='$k'");
		return $hsl;
	}
	function update_profil_tanpa_img($k,$nama,$detail,$status,$author){
		$hsl=$this->db->query("UPDATE tbl_profil SET profil_nama='$nama',profil_detail='$detail',profil_status='$status',profil_author='$author' WHERE profil_id='$k'");
		return $hsl;
	}
	function hapus_profil($k){
		$hsl=$this->db->query("DELETE FROM tbl_profil WHERE profil_id='$k'");
		return $hsl;
	}

	//front-end
	function profil($profil){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_profil.* FROM tbl_profil WHERE profil_ormawa_id='$ormawa'");
		return $hsl;
	}
	function profil_perpage($progil,$offset,$limit){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_profil.* FROM tbl_profil WHERE profil_ormawa_id='$ormawa' AND profil_jenis='$profil' limit $offset,$limit");
		return $hsl;
	}

}