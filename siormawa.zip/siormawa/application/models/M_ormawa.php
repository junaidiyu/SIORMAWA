<?php 
class M_ormawa extends CI_Model{

	function get_all_ormawa(){
		$hsl=$this->db->query("SELECT tbl_ormawa.*, jenis_kode, kampus_kode FROM tbl_ormawa JOIN tbl_jenis ON ormawa_jenis_id=jenis_id JOIN tbl_kampus ON ormawa_kampus_id=kampus_id ORDER BY ormawa_id ASC");
		return $hsl;
	}
	function get_ormawa_user(){
		$ormawa=$this->session->userdata('ormawa_id');
		$hsl=$this->db->query("SELECT tbl_ormawa.* FROM tbl_ormawa WHERE ormawa_id= '$ormawa' ORDER BY ormawa_id ASC");
		return $hsl;
	}
	function simpan_ormawa($kode,$nama,$logo,$no_sk,$tgl_sk,$author){
		$hsl=$this->db->query("INSERT INTO tbl_ormawa (ormawa_kode,ormawa_nama,ormawa_logo,ormawa_no_sk,ormawa_tgl_sk,ormawa_author) VALUES ('$kode','$nama','$logo','$no_sk','$tgl_sk','$author')");
		return $hsl;
	}
	function simpan_ormawa_tanpa_img($kode,$nama,$no_sk,$tgl_sk,$author){
		$hsl=$this->db->query("INSERT INTO tbl_ormawa (ormawa_kode,ormawa_nama,ormawa_no_sk,ormawa_tgl_sk,ormawa_author) VALUES ('$kode','$nama','$no_sk','$tgl_sk','$author')");
		return $hsl;
	}
	function update_ormawa($k,$kode,$nama,$logo,$no_sk,$tgl_sk,$author){
		$hsl=$this->db->query("UPDATE tbl_ormawa SET ormawa_kode='$kode',ormawa_nama='$nama',ormawa_logo='$logo',ormawa_no_sk='$no_sk',ormawa_tgl_sk='$tgl_sk',ormawa_author='$author' WHERE ormawa_id='$k'");
		return $hsl;
	}
	function update_ormawa_tanpa_img($k,$kode,$nama,$no_sk,$tgl_sk,$author){
		$hsl=$this->db->query("UPDATE tbl_ormawa SET ormawa_kode='$kode',ormawa_nama='$nama',ormawa_no_sk='$no_sk',ormawa_tgl_sk='$tgl_sk',ormawa_author='$author' WHERE ormawa_id='$k'");
		return $hsl;
	}
	function hapus_ormawa($k){
		$hsl=$this->db->query("DELETE FROM tbl_ormawa WHERE ormawa_id='$k'");
		return $hsl;
	}

	//front-end
	function get_ormawa(){
		$ormawa=$this->session->userdata('ormawa_id2');
		$hsl=$this->db->query("SELECT tbl_ormawa.* FROM tbl_ormawa WHERE ormawa_id= '$ormawa' ORDER BY ormawa_id ASC");
		return $hsl;
	}

}