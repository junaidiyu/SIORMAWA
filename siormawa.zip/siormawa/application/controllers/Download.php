<?php
class Download extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_ormawa');
		$this->load->model('m_kontak');
		$this->load->model('m_tema');
		$this->load->model('m_files');
		$this->load->helper('download');
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	}
	function index(){
		$x['judul']='Download';
		$x['all_ormawa']=$this->m_ormawa->get_all_ormawa();
		$x['ormawa']=$this->m_ormawa->get_ormawa();
		$x['kontak']=$this->m_kontak->get_kontak();
		$x['tema']=$this->m_tema->get_tema();
		$x['data']=$this->m_files->get_all_files();
		$this->load->view('depan/v_header',$x);
		$this->load->view('depan/v_download',$x);
		$this->load->view('depan/v_footer',$x);
	}

	function get_file(){
		$id=$this->uri->segment(3);
		$get_db=$this->m_files->get_file_byid($id);
		$q=$get_db->row_array();
		$file=$q['file_data'];
		$path='./assets/files/'.$file;
		$data = file_get_contents($path);
		$name = $file;
		force_download($name, $data);
	}

}
