<?php
class Visi_misi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_ormawa');
		$this->load->model('m_kontak');
		$this->load->model('m_tema');
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	}
	function index(){
		$x['judul']='Vision and Mission';
		$x['all_ormawa']=$this->m_ormawa->get_all_ormawa();
		$x['ormawa']=$this->m_ormawa->get_ormawa();
		$x['kontak']=$this->m_kontak->get_kontak();
		$x['tema']=$this->m_tema->get_tema();

		$x['tot_pengurus']=$this->db->get('tbl_pengurus')->num_rows();
		$x['tot_anggota']=$this->db->get('tbl_anggota')->num_rows();
		$x['tot_files']=$this->db->get('tbl_files')->num_rows();
		$x['tot_agenda']=$this->db->get('tbl_agenda')->num_rows();
		$this->load->view('depan/v_header',$x);
		$this->load->view('depan/v_visi_misi',$x);
		$this->load->view('depan/v_footer',$x);
	}
}
