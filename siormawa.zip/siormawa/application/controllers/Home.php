<?php
class Home extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_ormawa');
		$this->load->model('m_kontak');
		$this->load->model('m_tema');
		$this->load->model('m_tulisan');
		$this->load->model('m_galeri');
		$this->load->model('m_pengumuman');
		$this->load->model('m_agenda');
		$this->load->model('m_files');
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	}
	function index(){
		$x['judul']='Home';

		$x['all_ormawa']=$this->m_ormawa->get_all_ormawa();
		$x['ormawa']=$this->m_ormawa->get_ormawa();
		$x['kontak']=$this->m_kontak->get_kontak();
		$x['tema']=$this->m_tema->get_tema();
		$x['berita']=$this->m_tulisan->get_berita_home();
		$x['pengumuman']=$this->m_pengumuman->get_pengumuman_home();
		$x['agenda']=$this->m_agenda->get_agenda_home();
		$x['tot_pengurus']=$this->db->get('tbl_pengurus')->num_rows();
		$x['tot_anggota']=$this->db->get('tbl_anggota')->num_rows();
		$x['tot_files']=$this->db->get('tbl_files')->num_rows();
		$x['tot_agenda']=$this->db->get('tbl_agenda')->num_rows();
		$cekOrmawa=$this->m_ormawa->get_ormawa();
		if($cekOrmawa->num_rows()==0){
			$cekAllOrmawa=$this->m_ormawa->get_all_ormawa();
			foreach ($cekAllOrmawa->result_array() as $i) {
				$id2=$i['ormawa_id'];
			}
			$this->session->set_userdata('ormawa_id2',$id2);
			redirect ();
		}

		$this->load->view('depan/v_header',$x);
		$this->load->view('depan/v_home',$x);
		$this->load->view('depan/v_footer',$x);
	}
	function auth(){
		$id=$this->uri->segment(3);
		$cekOrmawa=$this->m_ormawa->get_ormawa();
		$this->session->set_userdata('ormawa_id2',$id);
		if($cekOrmawa->num_rows()==0){
			$cekAllOrmawa=$this->m_ormawa->get_all_ormawa();
			foreach ($cekAllOrmawa->result_array() as $i) {
				$id2=$i['ormawa_id'];
			}
			$this->session->set_userdata('ormawa_id2',$id2);
			redirect ();
		}
		redirect ();
	}

}
