<?php
class Kontak extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_kontak');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
	}


	function index(){
		$author=$this->session->userdata('nama');
		$x['title']		='SIORMAWA - Super Admin > Kontak';
		$x['judul']='Kontak';
		$x['data']=$this->m_kontak->get_all_kontak();

		$this->load->view('admin/v_header',$x);
  		$this->load->view('admin/v_sidebar',$x);
		$this->load->view('admin/v_kontak',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_kontak(){
		$author=$this->session->userdata('nama');
		$nama=strip_tags($this->input->post('xnama'));
		$email=strip_tags($this->input->post('xemail'));
		$wa=strip_tags($this->input->post('xwhatsapp'));
		$fb=strip_tags($this->input->post('xfacebook'));
		$ig=strip_tags($this->input->post('xinstagram'));
		$yt=strip_tags($this->input->post('xyoutube'));

		$this->m_kontak->simpan_kontak($nama,$email,$wa,$fb,$ig,$yt,$author);
		echo $this->session->set_flashdata('msg','success');
		redirect('admin/kontak');
								
	}
	
	function update_kontak(){
		$author=$this->session->userdata('nama');
	    $k=$this->input->post('kode');
		$nama=strip_tags($this->input->post('xnama'));
		$email=strip_tags($this->input->post('xemail'));
		$wa=strip_tags($this->input->post('xwhatsapp'));
		$fb=strip_tags($this->input->post('xfacebook'));
		$ig=strip_tags($this->input->post('xinstagram'));
		$yt=strip_tags($this->input->post('xyoutube'));

		$this->m_kontak->update_kontak_tanpa_img($k,$nama,$email,$wa,$fb,$ig,$yt,$author);
		echo $this->session->set_flashdata('msg','info');
		redirect('admin/kontak');
	}

	function hapus_kontak(){
		$k=$this->input->post('kode');
		$this->m_kontak->hapus_kontak($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/kontak');
	}

}