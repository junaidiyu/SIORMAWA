<?php
class Dashboard extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin/login');
            redirect($url);
        };
		$this->load->model('m_pengunjung');
	}
	function index(){
        if($this->session->userdata('akses')=='1'){
			$x['sbDashboard']			='class="active"';
			$x['sbArtikel']				='class="treeview"';
				$x['sbArtikelList']		='';
				$x['sbArtikelPost']		='';
				$x['sbArtikelKategori']	='';
			$x['sbPengguna']			='';
			$x['sbAgenda']				='';
			$x['sbPengumuman']			='';
			$x['sbFile']				='';
			$x['sbGallery']				='class="treeview"';
				$x['sbGalleryAlbum']	='';
				$x['sbGalleryPhotos']	='';
			$x['sbPengurus']			='';
			$x['sbAnggota']				='class="treeview"';
				$x['sbAnggotaList']		='';
				$x['sbAnggotaPrestasi']	='';
			$x['sbInbox']				='';
			$x['sbKomentar']			='';

			$x['title']		='SIORMAWA - Super Admin > Dashboard';
			$x['visitor'] = $this->m_pengunjung->statistik_pengujung();
			
			$this->load->view('admin/v_header',$x);
			$this->load->view('admin/v_sidebar',$x);
			$this->load->view('admin/v_dashboard',$x);
			$this->load->view('admin/v_footer',$x);
		}
		else{
			redirect('admin/login');
		}
	
	}
	
}