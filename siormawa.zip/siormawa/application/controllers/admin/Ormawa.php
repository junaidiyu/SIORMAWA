<?php
class Ormawa extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_ormawa');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
	}


	function index(){
		$author=$this->session->userdata('nama');
		$x['title']		='SIORMAWA - Super Admin > Profil Ormawa';
		$x['judul']='Ormawa';
		$x['data']=$this->m_ormawa->get_all_ormawa();

		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_ormawa',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_ormawa(){
				$author=$this->session->userdata('nama');
				$config['upload_path'] = './assets/images/ormawa'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //kode yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['xlogo']['name']))
	            {
	                if ($this->upload->do_upload('xlogo'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/ormawa/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/ormawa/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();

	                        $logo=$gbr['file_name'];
							$kode=strip_tags($this->input->post('xkode'));
							$nama=strip_tags($this->input->post('xnama'));
							$no_sk=strip_tags($this->input->post('xno_sk'));
							$tgl_sk=strip_tags($this->input->post('xtgl_sk'));

							$this->m_ormawa->simpan_ormawa($kode,$nama,$logo,$no_sk,$tgl_sk,$author);
							echo $this->session->set_flashdata('msg','success');
							redirect('admin/ormawa');
					}else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/ormawa');
	                }
	                 
	            }else{
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$no_sk=strip_tags($this->input->post('xno_sk'));
					$tgl_sk=strip_tags($this->input->post('xtgl_sk'));

					$this->m_ormawa->simpan_ormawa_tanpa_img($kode,$nama,$no_sk,$tgl_sk,$author);
					echo $this->session->set_flashdata('msg','success');
					redirect('admin/ormawa');
				}
				
	}
	
	function update_ormawa(){
				$author=$this->session->userdata('nama');
	            $config['upload_path'] = './assets/images/ormawa/'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //kode yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['xlogo']['name']))
	            {
	                if ($this->upload->do_upload('xlogo'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/ormawa/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/ormawa/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();
	                        $gambar=$this->input->post('gambar');
							$path='./assets/images/ormawa/'.$gambar;
							unlink($path);

	                        $logo=$gbr['file_name'];
	                        $k=$this->input->post('kode');
							$kode=strip_tags($this->input->post('xkode'));
							$nama=strip_tags($this->input->post('xnama'));
							$no_sk=strip_tags($this->input->post('xno_sk'));
							$tgl_sk=strip_tags($this->input->post('xtgl_sk'));

							$this->m_ormawa->update_ormawa($k,$kode,$nama,$logo,$no_sk,$tgl_sk,$author);
							echo $this->session->set_flashdata('msg','info');
							redirect('admin/ormawa');
	                    
	                }else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/ormawa');
	                }
	                
	            }else{
							$k=$this->input->post('kode');
							$kode=strip_tags($this->input->post('xkode'));
							$nama=strip_tags($this->input->post('xnama'));
							$no_sk=strip_tags($this->input->post('xno_sk'));
							$tgl_sk=strip_tags($this->input->post('xtgl_sk'));

							$this->m_ormawa->update_ormawa_tanpa_img($k,$kode,$nama,$no_sk,$tgl_sk,$author);
							echo $this->session->set_flashdata('msg','info');
							redirect('admin/ormawa');
	            } 

	}

	function hapus_ormawa(){
		$k=$this->input->post('kode');
		$gambar=$this->input->post('gambar');
		$path='./assets/images/ormawa/'.$gambar;
		unlink($path);
		$this->m_ormawa->hapus_ormawa($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/ormawa');
	}

}