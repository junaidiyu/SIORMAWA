<?php

class Pengurus_lap extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
		$this->load->model('m_pengurus');
	}


	function index(){
		$x['data']=$this->m_pengurus->get_all_pengurus();
		$this->load->view('admin/laporan/v_pengurus_lap',$x);
	}
}