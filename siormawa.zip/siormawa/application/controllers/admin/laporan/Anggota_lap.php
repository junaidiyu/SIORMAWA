<?php

class Anggota_lap extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
		$this->load->model('m_anggota');
	}


	function index(){
		$x['data']=$this->m_anggota->get_all_anggota();
		$this->load->view('admin/laporan/v_anggota_lap',$x);
	}
}