<?php
class Jenis extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_jenis');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
	}


	function index(){
		$author=$this->session->userdata('nama');

		$x['title']		='SIORMAWA - Super Admin > Jenis';
		$x['judul']='Jenis';
		$x['data']=$this->m_jenis->get_all_jenis();

		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_jenis',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_jenis(){
		$author=$this->session->userdata('nama');
		$kode=strip_tags($this->input->post('xkode'));
		$nama=strip_tags($this->input->post('xnama'));

		$this->m_jenis->simpan_jenis($kode,$nama,$author);
		echo $this->session->set_flashdata('msg','success');
		redirect('admin/jenis');
					
	}
	
	function update_jenis(){
		$author=$this->session->userdata('nama');
	    $k=$this->input->post('kode');
		$kode=strip_tags($this->input->post('xkode'));
		$nama=strip_tags($this->input->post('xnama'));

		$this->m_jenis->update_jenis_tanpa_img($k,$kode,$nama,$author);
		echo $this->session->set_flashdata('msg','info');
		redirect('admin/jenis');
	}

	function hapus_jenis(){
		$k=$this->input->post('kode');
		$this->m_jenis->hapus_jenis($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/jenis');
	}

}