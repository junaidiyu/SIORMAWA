<?php
class Inbox extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
		$this->load->model('m_kontak');
	}

	function index(){
		$x['sbDashboard']			='';
		$x['sbArtikel']				='class="treeview"';
			$x['sbArtikelList']		='';
			$x['sbArtikelPost']		='';
			$x['sbArtikelKategori']	='';
		$x['sbPengguna']			='';
		$x['sbAgenda']				='';
		$x['sbPengumuman']			='';
		$x['sbFile']				='';
		$x['sbGallery']				='class="treeview"';
			$x['sbGalleryAlbum']	='';
			$x['sbGalleryPhotos']	='';
		$x['sbPengurus']			='';
		$x['sbAnggota']				='class="treeview"';
			$x['sbAnggotaList']		='';
			$x['sbAnggotaPrestasi']	='';
		$x['sbInbox']				='class="active"';
		$x['sbKomentar']			='';


		$x['title']		='SIORMAWA - Super Admin > Inbox';
		$x['judul']='Inbox';
		$this->m_kontak->update_status_kontak();
		$x['data']=$this->m_kontak->get_all_inbox();
		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_inbox',$x);
		$this->load->view('admin/v_footer',$x);
	}

	function hapus_inbox(){
		$kode=$this->input->post('kode');
		$this->m_kontak->hapus_kontak($kode);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/inbox');
	}
}