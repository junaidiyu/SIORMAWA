<?php
class Login extends CI_Controller{
    function __construct(){
        parent:: __construct();
        $this->load->model('m_login');
        $this->load->model('m_kampus');
    }
    function index(){
     //   $this->load->view('admin/v_header');
        $this->load->view('admin/v_login');
     //   $this->load->view('admin/v_footer');
     //   $this->load->view('depan/v_footer');
    }
    function auth(){
        $username=strip_tags(str_replace("'", "", $this->input->post('username')));
        $password=strip_tags(str_replace("'", "", $this->input->post('password')));
        $kampus=$this->input->post('xkampus');
        $u=$username;
        $p=$password;
        $ka=$kampus;
        
        $cadmin=$this->m_login->cekadmin($u,$p);

        echo json_encode($cadmin);


        if($cadmin->num_rows() > 0){
         $this->session->set_userdata('masuk',true);
         $this->session->set_userdata('user',$u);
         $xcadmin=$cadmin->row_array();

          if($xcadmin['pengguna_level']=='1')
         {
            $this->session->set_userdata('akses','1');
            $idadmin=$xcadmin['pengguna_id'];
            $user_nama=$xcadmin['pengguna_nama'];
            $this->session->set_userdata('idadmin',$idadmin);
            $this->session->set_userdata('nama',$user_nama);
            redirect('admin/dashboard');
         }

         else if($xcadmin['pengguna_level']=='0')
         {
            $this->session->set_userdata('akses','1');
            $idadmin=$xcadmin['pengguna_id'];
            $user_nama=$xcadmin['pengguna_nama'];
            $idkampus=$xcadmin['pengguna_kampus_id'];
            $this->session->set_userdata('idadmin',$idadmin);
            $this->session->set_userdata('nama',$user_nama);
            $this->session->set_userdata('kampus_id',$idkampus);
            redirect('admin/dashboard');
         }
         else if($xcadmin['pengguna_level']=='2')
         {
             $this->session->set_userdata('akses','2');
             $idadmin=$xcadmin['pengguna_id'];
             $user_nama=$xcadmin['pengguna_nama'];
             $ormawa_id=$xcadmin['pengguna_ormawa_id'];
             $this->session->set_userdata('idadmin',$idadmin);
             $this->session->set_userdata('nama',$user_nama);
             $this->session->set_userdata('ormawa_id',$ormawa_id);
             redirect('ormawa/dashboard');
         }
         else
         {
             $this->session->set_userdata('akses','3');
             $idadmin=$xcadmin['pengguna_id'];
             $user_nama=$xcadmin['pengguna_nama'];
             $ormawa_id=$xcadmin['pengguna_ormawa_id'];
             $this->session->set_userdata('idadmin',$idadmin);
             $this->session->set_userdata('nama',$user_nama);
             redirect('kemahasiswaan/dashboard');
         }

       }else{
         echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button> Username Atau Password Salah</div>');
         redirect('admin/login');
       }

    }

    function logout(){
        $this->session->sess_destroy();
        redirect('administrator');
    }
}
