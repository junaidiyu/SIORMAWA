<?php
class Jurusan extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_jurusan');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
	}


	function index(){
		$x['sbDashboard']			='';
		$x['sbArtikel']				='class="treeview"';
			$x['sbArtikelList']		='';
			$x['sbArtikelPost']		='';
			$x['sbArtikelKategori']	='';
		$x['sbPengguna']			='';
		$x['sbAgenda']				='';
		$x['sbPengumuman']			='';
		$x['sbFile']				='';
		$x['sbGallery']				='class="treeview"';
			$x['sbGalleryAlbum']	='';
			$x['sbGalleryPhotos']	='';
		$x['sbJurusan']			='class="active"';
		$x['sbAnggota']				='class="treeview"';
			$x['sbAnggotaList']		='';
			$x['sbAnggotaPrestasi']	='';
		$x['sbInbox']				='';
		$x['sbKomentar']			='';


		$x['title']		='SIORMAWA - Super Admin > Jurusan';
		$x['judul']='Jurusan';
		$x['data']=$this->m_jurusan->get_all_jurusan();

		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_jurusan',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_jurusan(){
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$author=strip_tags($this->input->post('xauthor'));

					$this->m_jurusan->simpan_jurusan($kode,$nama,$author);
					echo $this->session->set_flashdata('msg','success');
					redirect('admin/jurusan');
								
	}
	
	function update_jurusan(){
				    $k=$this->input->post('kode');
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$author=strip_tags($this->input->post('xauthor'));

					$this->m_jurusan->update_jurusan_tanpa_img($k,$kode,$nama,$author);
					echo $this->session->set_flashdata('msg','info');
					redirect('admin/jurusan');
	}

	function hapus_jurusan(){
		$k=$this->input->post('kode');
		$this->m_jurusan->hapus_jurusan($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/jurusan');
	}

}