<?php
class Kampus extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_kampus');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
		$author=$this->session->userdata('nama');
	}


	function index(){
		$x['sbDashboard']			='';
		$x['sbArtikel']				='class="treeview"';
			$x['sbArtikelList']		='';
			$x['sbArtikelPost']		='';
			$x['sbArtikelKategori']	='';
		$x['sbPengguna']			='';
		$x['sbAgenda']				='';
		$x['sbPengumuman']			='';
		$x['sbFile']				='';
		$x['sbGallery']				='class="treeview"';
			$x['sbGalleryAlbum']	='';
			$x['sbGalleryPhotos']	='';
		$x['sbKampus']			='class="active"';
		$x['sbAnggota']				='class="treeview"';
			$x['sbAnggotaList']		='';
			$x['sbAnggotaPrestasi']	='';
		$x['sbInbox']				='';
		$x['sbKomentar']			='';


		$x['title']		='SIORMAWA - Super Admin > Kampus';
		$x['judul']='Kampus';
		$x['data']=$this->m_kampus->get_all_kampus();

		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_kampus',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_kampus(){
				$author=$this->session->userdata('nama');
				$config['upload_path'] = './assets/images/campus'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['filefoto']['name']))
	            {
	                if ($this->upload->do_upload('filefoto'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/campus/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/campus/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();

	                        $logo=$gbr['file_name'];
							$kode=strip_tags($this->input->post('xkode'));
							$nama=strip_tags($this->input->post('xnama'));
							$email=strip_tags($this->input->post('xemail'));
							$alamat=strip_tags($this->input->post('xalamat'));
							$website=strip_tags($this->input->post('xwebsite'));

							$this->m_kampus->simpan_kampus($kode,$nama,$email,$alamat,$website,$logo,$author);
							echo $this->session->set_flashdata('msg','success');
							redirect('admin/kampus');
					}else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/kampus');
	                }
	                 
	            }else{
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$email=strip_tags($this->input->post('xemail'));
					$alamat=strip_tags($this->input->post('xalamat'));
					$website=strip_tags($this->input->post('xwebsite'));

					$this->m_kampus->simpan_kampus_tanpa_img($kode,$nama,$email,$alamat,$website,$author);
					echo $this->session->set_flashdata('msg','success');
					redirect('admin/kampus');
				}
	}
	
	function update_kampus(){
				$author=$this->session->userdata('nama');
	            $config['upload_path'] = './assets/images/campus/'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['filefoto']['name']))
	            {
	                if ($this->upload->do_upload('filefoto'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/campus/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/campus/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();
	                        $gambar=$this->input->post('gambar');
							$path='./assets/images/campus/'.$gambar;
							unlink($path);

	                        $logo=$gbr['file_name'];

	                        $k=$this->input->post('kode');
							$kode=strip_tags($this->input->post('xkode'));
							$nama=strip_tags($this->input->post('xnama'));
							$email=strip_tags($this->input->post('xemail'));
							$alamat=strip_tags($this->input->post('xalamat'));
							$website=strip_tags($this->input->post('xwebsite'));

							$this->m_kampus->update_kampus($k,$kode,$nama,$email,$alamat,$website,$logo,$author);
							echo $this->session->set_flashdata('msg','info');
							redirect('admin/kampus');
	                    
	                }else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/kampus');
	                }
	                
	            }
	            else{

	                $k=$this->input->post('kode');
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$email=strip_tags($this->input->post('xemail'));
					$alamat=strip_tags($this->input->post('xalamat'));
					$website=strip_tags($this->input->post('xwebsite'));

					$this->m_kampus->update_kampus_tanpa_img($k,$kode,$nama,$email,$alamat,$website,$author);
					echo $this->session->set_flashdata('msg','info');
					redirect('admin/kampus');
	            } 

	}

	function hapus_kampus(){
		$k=$this->input->post('kode');
		$gambar=$this->input->post('gambar');
		$path='./assets/images/campus/'.$gambar;
		unlink($path);
		$this->m_kampus->hapus_kampus($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/kampus');
	}

}