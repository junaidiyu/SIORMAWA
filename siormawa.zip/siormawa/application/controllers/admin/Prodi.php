<?php
class Prodi extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_prodi');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
	}


	function index(){
		$x['sbDashboard']			='';
		$x['sbArtikel']				='class="treeview"';
			$x['sbArtikelList']		='';
			$x['sbArtikelPost']		='';
			$x['sbArtikelKategori']	='';
		$x['sbPengguna']			='';
		$x['sbAgenda']				='';
		$x['sbPengumuman']			='';
		$x['sbFile']				='';
		$x['sbGallery']				='class="treeview"';
			$x['sbGalleryAlbum']	='';
			$x['sbGalleryPhotos']	='';
		$x['sbProdi']			='class="active"';
		$x['sbAnggota']				='class="treeview"';
			$x['sbAnggotaList']		='';
			$x['sbAnggotaPrestasi']	='';
		$x['sbInbox']				='';
		$x['sbKomentar']			='';


		$x['title']		='SIORMAWA - Super Admin > Prodi';
		$x['judul']='Prodi';
		$x['data']=$this->m_prodi->get_all_prodi();

		$this->load->view('admin/v_header', $x);
  		$this->load->view('admin/v_sidebar', $x);
		$this->load->view('admin/v_prodi',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_prodi(){
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$author=strip_tags($this->input->post('xauthor'));

					$this->m_prodi->simpan_prodi($kode,$nama,$author);
					echo $this->session->set_flashdata('msg','success');
					redirect('admin/prodi');
								
	}
	
	function update_prodi(){
				    $k=$this->input->post('kode');
					$kode=strip_tags($this->input->post('xkode'));
					$nama=strip_tags($this->input->post('xnama'));
					$author=strip_tags($this->input->post('xauthor'));

					$this->m_prodi->update_prodi_tanpa_img($k,$kode,$nama,$author);
					echo $this->session->set_flashdata('msg','info');
					redirect('admin/prodi');
	}

	function hapus_prodi(){
		$k=$this->input->post('kode');
		$this->m_prodi->hapus_prodi($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/prodi');
	}

}