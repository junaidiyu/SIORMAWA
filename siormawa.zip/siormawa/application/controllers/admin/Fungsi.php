<?php
class Fungsi extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('admin');
            redirect($url);
        };
		$this->load->model('m_profil');
		$this->load->model('m_pengguna');
		$this->load->library('upload');
		$profil='fungsi';
		$author=$this->session->userdata('nama');
	}


	function index(){
		$profil='fungsi';
		$author=$this->session->userdata('nama');
		$x['title']		='SIORMAWA - Super Admin > Fungsi';
		$x['judul']='Fungsi';
		$x['data']=$this->m_profil->get_all_profil($profil);

		$this->load->view('admin/v_header',$x);
  		$this->load->view('admin/v_sidebar',$x);
		$this->load->view('admin/v_fungsi',$x);
		$this->load->view('admin/v_footer',$x);
	}

	function get_edit(){
		$profil='fungsi';
		$k=$this->uri->segment(4);
		$x['title']		='SIORMAWA - Super Admin > Edit Fungsi';
		$x['data']=$this->m_profil->get_profil_by_kode($profil,$k);
		$this->load->view('admin/v_header',$x);
  		$this->load->view('admin/v_sidebar',$x);
		$this->load->view('admin/v_edit_fungsi',$x);
		$this->load->view('admin/v_footer',$x);
	}
	
	function simpan_fungsi(){
				$profil='fungsi';
				$author=$this->session->userdata('nama');
				$config['upload_path'] = './assets/images/profile'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //detail yang terupload nantinya
	            

	            $this->upload->initialize($config);
	            if(!empty($_FILES['filefoto']['name']))
	            {
	                if ($this->upload->do_upload('filefoto'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/profile/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/profile/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();

	                        $photo=$gbr['file_name'];
							$nama=strip_tags($this->input->post('xnama'));
							$detail=strip_tags($this->input->post('xdetail'));

							$this->m_profil->simpan_profil($nama,$detail,$photo,$profil,$author);
							echo $this->session->set_flashdata('msg','success');
							redirect('admin/fungsi');
					}else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/fungsi');
	                }
	                 
	            }else{
					$nama=strip_tags($this->input->post('xnama'));
					$detail=strip_tags($this->input->post('xdetail'));

					$this->m_profil->simpan_profil_tanpa_img($nama,$detail,$profil,$author);
					echo $this->session->set_flashdata('msg','success');
					redirect('admin/fungsi');
				}
				
	}
	
	function update_fungsi(){
				$profil='fungsi';
				$author=$this->session->userdata('nama');

	            $config['upload_path'] = './assets/images/profile/'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //detail yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['filefoto']['name']))
	            {
	                if ($this->upload->do_upload('filefoto'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/profile/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 300;
	                        $config['height']= 300;
	                        $config['new_image']= './assets/images/profile/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();
	                        $gambar=$this->input->post('gambar');
							$path='./assets/images/profile/'.$gambar;
							unlink($path);

	                        $photo=$gbr['file_name'];

	                        $k=$this->input->post('kode');
							$nama=strip_tags($this->input->post('xnama'));
							$detail=strip_tags($this->input->post('xdetail'));
							$status=strip_tags($this->input->post('xstatus'));

							$this->m_profil->update_profil($k,$nama,$detail,$photo,$status,$author);
							echo $this->session->set_flashdata('msg','info');
							redirect('admin/fungsi');
	                    
	                }else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('admin/fungsi');
	                }
	                
	            }
	            else{

	                $k=$this->input->post('kode');
					$nama=strip_tags($this->input->post('xnama'));
					$detail=strip_tags($this->input->post('xdetail'));
					$status=strip_tags($this->input->post('xstatus'));

					$this->m_profil->update_profil_tanpa_img($k,$nama,$detail,$status,$author);
					echo $this->session->set_flashdata('msg','info');
					redirect('admin/fungsi');
	            } 

	}

	function hapus_fungsi(){
		$k=$this->input->post('kode');
		$gambar=$this->input->post('gambar');
		$path='./assets/images/profile/'.$gambar;
		unlink($path);
		$this->m_profil->hapus_profil($k);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('admin/fungsi');
	}

}