<?php

class Pengurus_reg extends CI_Controller{
	function __construct(){
		parent::__construct();
		/*
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
        */
		$this->load->model('m_ormawa');
		$this->load->model('m_kontak');
		$this->load->model('m_tema');
		$this->load->model('m_pengurus');
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	}


	function index(){
		$x['judul']='Organizer Registration';
		$x['all_ormawa']=$this->m_ormawa->get_all_ormawa();
		$x['ormawa']=$this->m_ormawa->get_ormawa();
		$x['kontak']=$this->m_kontak->get_kontak();
		$x['tema']=$this->m_tema->get_tema();
		$x['data']=$this->m_pengurus->get_all_pengurus();

		$this->load->view('depan/v_header',$x);
		$this->load->view('depan/registrasi/v_pengurus_reg',$x);
		$this->load->view('depan/v_footer',$x);
	}
}