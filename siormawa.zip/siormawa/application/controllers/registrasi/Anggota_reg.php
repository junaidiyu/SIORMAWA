<?php

class Anggota_reg extends CI_Controller{
	function __construct(){
		parent::__construct();
		/*
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('administrator');
            redirect($url);
        };
        */
		$this->load->model('m_ormawa');
		$this->load->model('m_kontak');
		$this->load->model('m_tema');
		$this->load->model('m_anggota');
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	}


	function index(){
		$x['judul']='Member Registration';
		$x['all_ormawa']=$this->m_ormawa->get_all_ormawa();
		$x['ormawa']=$this->m_ormawa->get_ormawa();
		$x['kontak']=$this->m_kontak->get_kontak();
		$x['tema']=$this->m_tema->get_tema();
		$x['data']=$this->m_anggota->get_all_anggota();

		$this->load->view('depan/v_header',$x);
		$this->load->view('depan/registrasi/v_anggota_reg',$x);
		$this->load->view('depan/v_footer',$x);
	}
}